import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Overlay2, c as Title2, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, i as Description2, k as require_jsx_runtime, l as Dialog$1, m as DialogPortal$1, n as Cancel, o as Portal2, p as DialogOverlay$1, r as Content2, s as Root2, t as Action, u as DialogClose, w as Slot } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as FolderOpen, a as SquareStack, c as Search, d as List, f as LayoutGrid, g as Gauge, h as Info, i as TriangleAlert, l as RotateCw, m as Keyboard, n as ZoomOut, o as SquareCheckBig, p as Layers, r as X, s as Settings, t as ZoomIn, u as MousePointer2, v as ExternalLink, y as Copy } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as cn, i as TooltipTrigger, n as Tooltip, o as isEditableTarget, r as TooltipContent, s as uniqueName } from "./router-Bz1KZ2n7.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as openDB } from "../_libs/idb.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as useVirtualizer } from "../_libs/@tanstack/react-virtual+[...].mjs";
import { t as Root$1 } from "../_libs/radix-ui__react-separator.mjs";
import { n as Root$2, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DD0Nd1vZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,opacity,transform,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			destructive: "bg-reject text-reject-fg hover:opacity-90",
			outline: "border border-border bg-transparent hover:bg-secondary",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent",
			ghost: "hover:bg-secondary",
			link: "text-primary underline-offset-4 hover:underline",
			select: "bg-select text-select-fg hover:opacity-90",
			maybe: "bg-maybe text-maybe-fg hover:opacity-90"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-11 rounded-md px-5",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function formatBytes(n) {
	if (!Number.isFinite(n) || n < 0) return "—";
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function formatRes(w, h) {
	if (!w || !h) return "—";
	return `${w.toLocaleString()} × ${h.toLocaleString()}`;
}
function formatWhen(iso) {
	if (!iso) return "—";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function formatProgress(done, total) {
	if (!total) return "0%";
	return `${(done / total * 100).toFixed(2)}%`;
}
function padIndex(n, width = 4) {
	return String(n).padStart(width, "0");
}
var DEMO_PROJECT_ID = "demo-fls3n-2026";
var DEMO_COUNT = 5e3;
var DEMO_NAME = "FLS3N_2026";
var DEMO_SOURCE = "Demo / FLS3N 2026";
var DEMO_SOURCES = [
	{
		key: "dancer",
		url: "/demo/dancer.jpg",
		label: "traditional dancer",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 800,
		shutter: "1/250",
		aperture: "f/4.0",
		focalLength: "70mm",
		size: 8388608
	},
	{
		key: "choir",
		url: "/demo/choir.jpg",
		label: "choir",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 1600,
		shutter: "1/125",
		aperture: "f/4.0",
		focalLength: "35mm",
		size: 9437184
	},
	{
		key: "portrait",
		url: "/demo/portrait.jpg",
		label: "portrait",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 400,
		shutter: "1/320",
		aperture: "f/4.0",
		focalLength: "105mm",
		size: 7340032
	},
	{
		key: "gamelan",
		url: "/demo/gamelan.jpg",
		label: "gamelan",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 640,
		shutter: "1/160",
		aperture: "f/4.0",
		focalLength: "55mm",
		size: 8912896
	},
	{
		key: "dance",
		url: "/demo/dance.jpg",
		label: "contemporary dance",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 3200,
		shutter: "1/500",
		aperture: "f/4.0",
		focalLength: "50mm",
		size: 6815744
	},
	{
		key: "audience",
		url: "/demo/audience.jpg",
		label: "audience",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 6400,
		shutter: "1/80",
		aperture: "f/4.0",
		focalLength: "18mm",
		size: 5505024
	},
	{
		key: "backstage",
		url: "/demo/backstage.jpg",
		label: "backstage",
		width: 6e3,
		height: 4e3,
		camera: "Sony ILCE-6400",
		lens: "E 18-105mm F4 G OSS",
		iso: 1250,
		shutter: "1/60",
		aperture: "f/4.0",
		focalLength: "24mm",
		size: 10485760
	}
];
var BURST = 4;
function sourceForIndex(index) {
	return DEMO_SOURCES[Math.floor(index / BURST) % DEMO_SOURCES.length];
}
function makeDemoPhoto(index) {
	const src = sourceForIndex(index);
	const n = index + 1;
	const filename = `IMG_${padIndex(n)}.JPG`;
	const burstOffset = index % BURST;
	const isoJitter = src.iso + burstOffset * 50;
	const isoStamp = new Date(Date.UTC(2026, 8, 23, 14, 35, 0) + index * 1200).toISOString();
	return {
		id: `demo-${padIndex(n)}`,
		filename,
		path: `${DEMO_SOURCE}/${filename}`,
		status: "unsorted",
		timestamp: null,
		size: src.size + burstOffset * 17408,
		width: src.width,
		height: src.height,
		format: "JPEG",
		createdAt: isoStamp,
		modifiedAt: isoStamp,
		dateTaken: isoStamp.replace("T", " ").slice(0, 19),
		camera: src.camera,
		lens: src.lens,
		iso: isoJitter,
		shutter: src.shutter,
		aperture: src.aperture,
		focalLength: src.focalLength,
		sourceKey: src.key,
		destFilename: null,
		destPath: null,
		error: null,
		rotation: 0,
		isDemo: true,
		isRaw: false,
		quality: null
	};
}
function buildDemoCatalog() {
	const photos = new Array(DEMO_COUNT);
	for (let i = 0; i < DEMO_COUNT; i++) photos[i] = makeDemoPhoto(i);
	return photos;
}
function demoUrl(photo) {
	return DEMO_SOURCES.find((s) => s.key === photo.sourceKey)?.url ?? DEMO_SOURCES[0].url;
}
function countByStatus(photos) {
	const counts = {
		all: photos.length,
		select: 0,
		alternative: 0,
		reject: 0,
		unsorted: 0
	};
	for (const p of photos) counts[p.status] += 1;
	return counts;
}
function cmpStr(a, b) {
	return (a ?? "").localeCompare(b ?? "", void 0, {
		numeric: true,
		sensitivity: "base"
	});
}
function sortPhotos(photos, sort) {
	const list = photos.slice();
	switch (sort) {
		case "filename-az":
			list.sort((a, b) => cmpStr(a.filename, b.filename));
			break;
		case "filename-za":
			list.sort((a, b) => cmpStr(b.filename, a.filename));
			break;
		case "date-taken":
			list.sort((a, b) => cmpStr(a.dateTaken, b.dateTaken) || cmpStr(a.filename, b.filename));
			break;
		case "date-modified":
			list.sort((a, b) => cmpStr(a.modifiedAt, b.modifiedAt) || cmpStr(a.filename, b.filename));
			break;
		case "file-size":
			list.sort((a, b) => b.size - a.size || cmpStr(a.filename, b.filename));
			break;
		case "camera":
			list.sort((a, b) => cmpStr(a.camera, b.camera) || cmpStr(a.filename, b.filename));
			break;
		case "focal-length": list.sort((a, b) => cmpStr(a.focalLength, b.focalLength) || cmpStr(a.filename, b.filename));
	}
	return list;
}
function applyFilter(photos, filter, query, sort) {
	const q = query.trim().toLowerCase();
	let list = photos;
	if (filter !== "all") list = list.filter((p) => p.status === filter);
	if (q) list = list.filter((p) => p.filename.toLowerCase().includes(q) || p.path.toLowerCase().includes(q) || p.format.toLowerCase().includes(q) || (p.camera ?? "").toLowerCase().includes(q));
	return sortPhotos(list, sort);
}
function nextUnsortedIndex(photos, fromIndex, dir) {
	if (!photos.length) return 0;
	const len = photos.length;
	for (let step = 1; step <= len; step++) {
		const i = (fromIndex + dir * step + len * 8) % len;
		if (photos[i]?.status === "unsorted") return i;
	}
	return Math.max(0, Math.min(fromIndex, len - 1));
}
function searchPhotos(photos, query) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	const out = [];
	for (const p of photos) if (p.filename.toLowerCase().includes(q) || p.path.toLowerCase().includes(q) || p.id.toLowerCase().includes(q)) {
		out.push(p);
		if (out.length >= 80) break;
	}
	return out;
}
function jumpToFile(photos, query) {
	const q = query.trim().toLowerCase();
	if (!q) return null;
	const exact = photos.find((p) => p.filename.toLowerCase() === q);
	if (exact) return exact;
	const withExt = photos.find((p) => p.filename.toLowerCase() === `${q}.jpg`);
	if (withExt) return withExt;
	return photos.find((p) => p.filename.toLowerCase().includes(q)) ?? null;
}
var SUPPORTED_IMAGE_EXT = [
	"jpg",
	"jpeg",
	"png",
	"webp",
	"tif",
	"tiff",
	"gif",
	"bmp",
	"avif",
	"heic",
	"heif"
];
var RAW_EXT = [
	"arw",
	"cr2",
	"cr3",
	"nef",
	"raf",
	"dng",
	"orf",
	"rw2"
];
var ALL_EXT = [...SUPPORTED_IMAGE_EXT, ...RAW_EXT];
function extOf(filename) {
	const d = filename.lastIndexOf(".");
	return d >= 0 ? filename.slice(d + 1).toLowerCase() : "";
}
function isSupportedFilename(filename) {
	return ALL_EXT.includes(extOf(filename));
}
function isRawFilename(filename) {
	return RAW_EXT.includes(extOf(filename));
}
function formatOf(filename) {
	const e = extOf(filename);
	if (e === "jpg" || e === "jpeg") return "JPEG";
	if (e === "tif" || e === "tiff") return "TIFF";
	return e.toUpperCase() || "FILE";
}
var FOLDER_OF = {
	select: "selectFolder",
	alternative: "alternativeFolder",
	reject: "rejectFolder"
};
function folderPath(project, status) {
	return project[FOLDER_OF[status]];
}
async function writeToDir(dir, filename, blob) {
	const writable = await (await dir.getFileHandle(filename, { create: true })).createWritable();
	await writable.write(blob);
	await writable.close();
}
async function placePhoto(opts) {
	const { photo, status, project, blob, destHandles, existingNames, conflictChoice } = opts;
	const folder = folderPath(project, status);
	let destFilename = photo.filename;
	if (existingNames.has(destFilename)) {
		if (!conflictChoice) return {
			ok: false,
			conflict: true,
			destFilename,
			destPath: `${folder}/${destFilename}`
		};
		if (conflictChoice === "skip") return {
			ok: true,
			skipped: true,
			destFilename: null,
			destPath: null
		};
		if (conflictChoice === "rename") destFilename = uniqueName(photo.filename, existingNames);
	}
	const destPath = `${folder}/${destFilename}`;
	if (project.isDemo || !blob) {
		existingNames.add(destFilename);
		return {
			ok: true,
			destFilename,
			destPath
		};
	}
	const dir = destHandles[status];
	if (!dir) {
		existingNames.add(destFilename);
		return {
			ok: true,
			destFilename,
			destPath
		};
	}
	try {
		await writeToDir(dir, destFilename, blob);
		existingNames.add(destFilename);
		return {
			ok: true,
			destFilename,
			destPath
		};
	} catch (err) {
		const message = err instanceof Error ? err.message : "Unknown error";
		return {
			ok: false,
			destFilename: null,
			destPath: null,
			error: /denied|permission/i.test(message) ? "Permission denied" : /quota|space|full/i.test(message) ? "Disk full" : /lock|busy/i.test(message) ? "File locked" : /missing|not found/i.test(message) ? "File missing" : message
		};
	}
}
var blobUrls = /* @__PURE__ */ new Map();
var fileBlobs = /* @__PURE__ */ new Map();
function rememberBlob(id, blob) {
	fileBlobs.set(id, blob);
}
function getBlob(id) {
	return fileBlobs.get(id) ?? null;
}
function objectUrlFor(photo) {
	if (photo.isDemo) return demoUrl(photo);
	const existing = blobUrls.get(photo.id);
	if (existing) return existing;
	const blob = fileBlobs.get(photo.id);
	if (!blob) return "";
	const url = URL.createObjectURL(blob);
	blobUrls.set(photo.id, url);
	return url;
}
function collectImageFiles(fileList) {
	return fileList.filter((f) => isSupportedFilename(f.name)).sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true }));
}
async function indexFiles(files, sourceFolder) {
	const photos = [];
	for (let i = 0; i < files.length; i++) {
		const file = files[i];
		rememberBlob(`file-${i}-${file.name}`, file);
		const id = `file-${i}-${file.name}`;
		photos.push({
			id,
			filename: file.name,
			path: `${sourceFolder}/${file.name}`,
			status: "unsorted",
			timestamp: null,
			size: file.size,
			width: 0,
			height: 0,
			format: formatOf(file.name),
			createdAt: file.lastModified ? new Date(file.lastModified).toISOString() : null,
			modifiedAt: file.lastModified ? new Date(file.lastModified).toISOString() : null,
			dateTaken: null,
			camera: null,
			lens: null,
			iso: null,
			shutter: null,
			aperture: null,
			focalLength: null,
			sourceKey: id,
			destFilename: null,
			destPath: null,
			error: null,
			rotation: 0,
			isDemo: false,
			isRaw: isRawFilename(file.name),
			quality: null
		});
	}
	return photos;
}
async function readExif(photo) {
	if (photo.isDemo) return {};
	const blob = getBlob(photo.id);
	if (!blob) return {};
	try {
		const data = await (await import("../_libs/exifr.mjs").then((n) => n.t)).default.parse(blob, { pick: [
			"Make",
			"Model",
			"LensModel",
			"Lens",
			"ISO",
			"ISOSpeedRatings",
			"ExposureTime",
			"FNumber",
			"FocalLength",
			"DateTimeOriginal",
			"CreateDate",
			"ImageWidth",
			"ImageHeight",
			"ExifImageWidth",
			"ExifImageHeight"
		] });
		if (!data) return {};
		const camera = [data.Make, data.Model].filter(Boolean).join(" ") || null;
		const shutter = typeof data.ExposureTime === "number" ? data.ExposureTime >= 1 ? `${data.ExposureTime}s` : `1/${Math.round(1 / data.ExposureTime)}` : null;
		return {
			camera,
			lens: data.LensModel ?? data.Lens ?? null,
			iso: data.ISO ?? data.ISOSpeedRatings ?? null,
			shutter,
			aperture: typeof data.FNumber === "number" ? `f/${data.FNumber}` : null,
			focalLength: typeof data.FocalLength === "number" ? `${Math.round(data.FocalLength)}mm` : null,
			dateTaken: data.DateTimeOriginal ? new Date(data.DateTimeOriginal).toISOString() : data.CreateDate ? new Date(data.CreateDate).toISOString() : null,
			width: data.ImageWidth ?? data.ExifImageWidth ?? photo.width,
			height: data.ImageHeight ?? data.ExifImageHeight ?? photo.height
		};
	} catch {
		return {};
	}
}
var cache = /* @__PURE__ */ new Map();
function luminanceOf(r, g, b) {
	return .2126 * r + .7152 * g + .0722 * b;
}
function dHash(data, w, h) {
	let bits = "";
	for (let y = 0; y < h; y++) for (let x = 0; x < w - 1; x++) {
		const i = (y * w + x) * 4;
		const j = (y * w + x + 1) * 4;
		const a = luminanceOf(data[i], data[i + 1], data[i + 2]);
		const b = luminanceOf(data[j], data[j + 1], data[j + 2]);
		bits += a > b ? "1" : "0";
	}
	let hex = "";
	for (let i = 0; i < bits.length; i += 4) hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
	return hex;
}
function hamming(a, b) {
	const n = Math.min(a.length, b.length);
	let d = 0;
	for (let i = 0; i < n; i++) if (a[i] !== b[i]) d += 1;
	d += Math.abs(a.length - b.length);
	return d;
}
function sharpnessBand(score) {
	if (score > 180) return "high";
	if (score > 55) return "medium";
	return "low";
}
function exposureBand(lum) {
	if (lum < 28) return "very-dark";
	if (lum < 70) return "dark";
	if (lum > 230) return "very-bright";
	if (lum > 190) return "bright";
	return "good";
}
async function detectFaces(bitmap) {
	const FD = window.FaceDetector;
	if (!FD) return null;
	try {
		return (await new FD({ fastMode: true }).detect(bitmap)).length;
	} catch {
		return null;
	}
}
async function analyzePhoto(photo) {
	const hit = cache.get(photo.sourceKey);
	if (hit) return hit;
	const src = objectUrlFor(photo);
	if (!src || typeof document === "undefined") return null;
	try {
		const blob = await (await fetch(src)).blob();
		const bitmap = await createImageBitmap(blob);
		const size = 128;
		const canvas = document.createElement("canvas");
		canvas.width = size;
		canvas.height = size;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) {
			bitmap.close();
			return null;
		}
		ctx.drawImage(bitmap, 0, 0, size, size);
		const d = ctx.getImageData(0, 0, size, size).data;
		let sum = 0;
		let hi = 0;
		let lo = 0;
		let lap = 0;
		for (let y = 1; y < 127; y++) for (let x = 1; x < 127; x++) {
			const i = (y * size + x) * 4;
			const lum = luminanceOf(d[i], d[i + 1], d[i + 2]);
			sum += lum;
			if (lum > 245) hi += 1;
			if (lum < 12) lo += 1;
			const up = luminanceOf(d[i - 512], d[i - 512 + 1], d[i - 512 + 2]);
			const down = luminanceOf(d[i + 512], d[i + 512 + 1], d[i + 512 + 2]);
			const left = luminanceOf(d[i - 4], d[i - 3], d[i - 2]);
			const right = luminanceOf(d[i + 4], d[i + 5], d[i + 6]);
			const v = Math.abs(4 * lum - up - down - left - right);
			lap += v;
		}
		const pixels = 16384;
		const inner = 15876;
		const luminance = sum / pixels;
		const sharpnessScore = lap / inner;
		const hashCanvas = document.createElement("canvas");
		hashCanvas.width = 9;
		hashCanvas.height = 8;
		const hctx = hashCanvas.getContext("2d");
		let phash = "";
		if (hctx) {
			hctx.drawImage(bitmap, 0, 0, 9, 8);
			phash = dHash(hctx.getImageData(0, 0, 9, 8).data, 9, 8);
		}
		const faces = await detectFaces(bitmap);
		bitmap.close();
		const result = {
			sharpness: sharpnessBand(sharpnessScore),
			sharpnessScore,
			exposure: exposureBand(luminance),
			luminance,
			highlightClip: hi / pixels,
			shadowClip: lo / pixels,
			faces,
			eyes: faces === null ? "n/a" : "n/a",
			duplicateSimilarity: 0,
			phash
		};
		cache.set(photo.sourceKey, result);
		return result;
	} catch {
		return null;
	}
}
function similarityPercent(a, b) {
	if (!a?.phash || !b?.phash) return 0;
	const dist = hamming(a.phash, b.phash);
	const max = Math.max(a.phash.length, 1);
	return Math.round((1 - dist / max) * 100);
}
function similarGroup(photos, current, limit = 8) {
	if (!current.quality?.phash) return photos.filter((p) => p.sourceKey === current.sourceKey && p.id !== current.id).slice(0, limit);
	return photos.filter((p) => p.id !== current.id && p.quality?.phash).map((p) => ({
		p,
		sim: similarityPercent(current.quality, p.quality)
	})).filter((x) => x.sim >= 86).sort((a, b) => b.sim - a.sim).slice(0, limit).map((x) => x.p);
}
var memory = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
function thumbKey(photo, size) {
	return `${photo.sourceKey}:${size}`;
}
function drawThumb(bitmap, size) {
	const scale = Math.min(size / bitmap.width, size / bitmap.height, 1);
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx) return "";
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "medium";
	ctx.drawImage(bitmap, 0, 0, w, h);
	return canvas.toDataURL("image/jpeg", .72);
}
async function getThumbnail(photo, size) {
	const key = thumbKey(photo, size);
	const hit = memory.get(key);
	if (hit) return hit;
	const pending = inflight.get(key);
	if (pending) return pending;
	const work = (async () => {
		const src = objectUrlFor(photo);
		if (!src) return "";
		try {
			const blob = await (await fetch(src)).blob();
			const bitmap = await createImageBitmap(blob);
			const url = drawThumb(bitmap, size);
			bitmap.close();
			if (url) memory.set(key, url);
			return url;
		} catch {
			return src;
		}
	})();
	inflight.set(key, work);
	try {
		return await work;
	} finally {
		inflight.delete(key);
	}
}
function preloadFull(photo) {
	const src = objectUrlFor(photo);
	if (!src) return;
	const img = new Image();
	img.decoding = "async";
	img.src = src;
}
var dbPromise = null;
function getDb() {
	if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("IndexedDB unavailable"));
	if (!dbPromise) dbPromise = openDB("photo-sorter", 1, { upgrade(db) {
		if (!db.objectStoreNames.contains("session")) db.createObjectStore("session");
		if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
	} });
	return dbPromise;
}
async function loadSession() {
	try {
		return await (await getDb()).get("session", "current") ?? null;
	} catch {
		return null;
	}
}
async function saveSession(record) {
	try {
		await (await getDb()).put("session", record, "current");
	} catch {}
}
async function clearSession() {
	try {
		await (await getDb()).delete("session", "current");
	} catch {}
}
function csvEscape(value) {
	if (/[",\n]/.test(value)) return `"${value.replaceAll("\"", "\"\"")}"`;
	return value;
}
function buildCsv(photos) {
	return ["filename,status,path,timestamp", ...photos.filter((p) => p.status !== "unsorted").map((p) => {
		const ts = p.timestamp ? new Date(p.timestamp).toISOString().replace("T", " ").slice(0, 19) : "";
		const path = p.destPath ?? p.path;
		return [
			p.filename,
			p.status.toUpperCase(),
			path,
			ts
		].map(csvEscape).join(",");
	})].join("\n");
}
function buildJson(project, photos) {
	return JSON.stringify({
		project: project.name,
		source: project.sourceFolder,
		mode: project.mode,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		photos: photos.filter((p) => p.status !== "unsorted").map((p) => ({
			filename: p.filename,
			status: p.status.toUpperCase(),
			path: p.destPath ?? p.path,
			timestamp: p.timestamp ? new Date(p.timestamp).toISOString() : null
		}))
	}, null, 2);
}
function downloadText(filename, content, mime) {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var AUTO_SAVE_MS = 180;
var saveTimer = null;
function defaultProject(partial) {
	return {
		id: DEMO_PROJECT_ID,
		name: DEMO_NAME,
		createdAt: Date.now(),
		updatedAt: Date.now(),
		sourceFolder: DEMO_SOURCE,
		selectFolder: `${DEMO_SOURCE}/SELECT`,
		alternativeFolder: `${DEMO_SOURCE}/ALTERNATIVE`,
		rejectFolder: `${DEMO_SOURCE}/REJECT`,
		mode: "copy",
		isDemo: true,
		photoCount: DEMO_COUNT,
		...partial
	};
}
function applyStatuses(photos, statuses) {
	return photos.map((p) => {
		const s = statuses[p.id];
		if (!s) return p;
		return {
			...p,
			status: s.status,
			timestamp: s.timestamp,
			destPath: s.destPath,
			destFilename: s.destFilename,
			rotation: s.rotation,
			error: s.error
		};
	});
}
function toSession(state) {
	if (!state.project) return null;
	const statuses = {};
	for (const p of state.photos) {
		if (p.status === "unsorted" && !p.rotation && !p.error) continue;
		statuses[p.id] = {
			status: p.status,
			timestamp: p.timestamp,
			destPath: p.destPath,
			destFilename: p.destFilename,
			rotation: p.rotation,
			error: p.error
		};
	}
	return {
		project: {
			...state.project,
			updatedAt: Date.now(),
			photoCount: state.photos.length
		},
		currentId: state.currentId,
		filter: state.filter,
		sortOrder: state.sortOrder,
		fastSort: state.fastSort,
		thumbnailSize: state.thumbnailSize,
		qualityAssist: state.qualityAssist,
		showSimilar: state.showSimilar,
		autoAdvance: state.autoAdvance,
		statuses,
		undo: state.undo,
		redo: state.redo
	};
}
function scheduleSave(get) {
	if (typeof window === "undefined") return;
	if (saveTimer) window.clearTimeout(saveTimer);
	saveTimer = window.setTimeout(() => {
		const rec = toSession(get());
		if (rec) saveSession(rec);
	}, AUTO_SAVE_MS);
}
function visibleList(state) {
	return applyFilter(state.photos, state.filter, state.query, state.sortOrder);
}
function indexOfId(list, id) {
	if (!id) return 0;
	const i = list.findIndex((p) => p.id === id);
	return i < 0 ? 0 : i;
}
var useSorter = create((set, get) => ({
	hydrated: false,
	view: "home",
	resumeAvailable: null,
	project: null,
	photos: [],
	currentId: null,
	filter: "all",
	query: "",
	sortOrder: "filename-az",
	fastSort: false,
	fullscreen: false,
	thumbnailSize: 88,
	qualityAssist: true,
	showSimilar: true,
	autoAdvance: true,
	zoom: 1,
	panX: 0,
	panY: 0,
	settingsOpen: false,
	searchOpen: false,
	jumpOpen: false,
	selectedOpen: false,
	shortcutsOpen: false,
	foldersOpen: false,
	previewError: null,
	conflict: null,
	fileError: null,
	jumpMiss: null,
	undo: [],
	redo: [],
	destHandles: {},
	destNames: {
		select: /* @__PURE__ */ new Set(),
		alternative: /* @__PURE__ */ new Set(),
		reject: /* @__PURE__ */ new Set()
	},
	indexing: false,
	indexProgress: 0,
	hydrate: async () => {
		set({
			hydrated: true,
			resumeAvailable: await loadSession()
		});
	},
	prepareDemo: () => {
		set({
			view: "setup",
			project: defaultProject(),
			photos: [],
			resumeAvailable: null,
			conflict: null,
			fileError: null
		});
	},
	confirmStart: () => {
		const state = get();
		const project = state.project ?? defaultProject();
		let photos = state.photos;
		if (project.isDemo && photos.length === 0) photos = buildDemoCatalog();
		const currentId = photos[0]?.id ?? null;
		set({
			view: "workspace",
			project: {
				...project,
				photoCount: photos.length
			},
			photos,
			currentId,
			filter: "all",
			fastSort: false,
			zoom: 1,
			panX: 0,
			panY: 0,
			undo: [],
			redo: [],
			destNames: {
				select: /* @__PURE__ */ new Set(),
				alternative: /* @__PURE__ */ new Set(),
				reject: /* @__PURE__ */ new Set()
			}
		});
		scheduleSave(get);
		queueMicrotask(() => {
			get().preloadNeighbors();
			get().analyzeCurrent();
		});
	},
	declineResume: () => set({ resumeAvailable: null }),
	resumeSession: () => {
		const rec = get().resumeAvailable;
		if (!rec) return;
		const photos = rec.project.isDemo ? applyStatuses(buildDemoCatalog(), rec.statuses) : get().photos.length ? applyStatuses(get().photos, rec.statuses) : [];
		if (rec.project.isDemo || photos.length) {
			set({
				view: "workspace",
				project: rec.project,
				photos,
				currentId: rec.currentId ?? photos[0]?.id ?? null,
				filter: rec.filter,
				sortOrder: rec.sortOrder,
				fastSort: rec.fastSort,
				thumbnailSize: rec.thumbnailSize,
				qualityAssist: rec.qualityAssist,
				showSimilar: rec.showSimilar,
				autoAdvance: rec.autoAdvance,
				undo: rec.undo,
				redo: rec.redo,
				resumeAvailable: null,
				zoom: 1,
				panX: 0,
				panY: 0
			});
			scheduleSave(get);
			queueMicrotask(() => {
				get().preloadNeighbors();
				get().analyzeCurrent();
			});
			return;
		}
		set({
			view: "home",
			resumeAvailable: rec
		});
	},
	importFiles: async (files, folderName) => {
		set({
			indexing: true,
			indexProgress: 0
		});
		const photos = await indexFiles(collectImageFiles(files), folderName || "SOURCE");
		set({
			indexing: false,
			indexProgress: 1,
			project: defaultProject({
				id: `proj-${Date.now()}`,
				name: folderName || "Untitled",
				sourceFolder: folderName || "SOURCE",
				selectFolder: `${folderName || "SOURCE"}/SELECT`,
				alternativeFolder: `${folderName || "SOURCE"}/ALTERNATIVE`,
				rejectFolder: `${folderName || "SOURCE"}/REJECT`,
				isDemo: false,
				photoCount: photos.length
			}),
			photos,
			view: "setup",
			currentId: photos[0]?.id ?? null
		});
		(async () => {
			for (let i = 0; i < Math.min(photos.length, 40); i++) {
				const extra = await readExif(photos[i]);
				if (Object.keys(extra).length) set((s) => ({ photos: s.photos.map((p) => p.id === photos[i].id ? {
					...p,
					...extra
				} : p) }));
			}
		})();
	},
	setMode: (mode) => set((s) => ({ project: s.project ? {
		...s.project,
		mode
	} : s.project })),
	setFolders: (partial) => set((s) => ({ project: s.project ? {
		...s.project,
		...partial
	} : s.project })),
	setFilter: (filter) => {
		set({ filter });
		const list = visibleList(get());
		if (!list.find((p) => p.id === get().currentId)) set({
			currentId: list[0]?.id ?? null,
			zoom: 1,
			panX: 0,
			panY: 0,
			previewError: null
		});
		scheduleSave(get);
	},
	setQuery: (query) => {
		set({
			query,
			jumpMiss: null
		});
		const list = visibleList(get());
		if (query && list.length && !list.find((p) => p.id === get().currentId)) set({ currentId: list[0]?.id ?? null });
	},
	setSort: (sortOrder) => {
		set({ sortOrder });
		scheduleSave(get);
	},
	setFastSort: (fastSort) => {
		set({
			fastSort,
			filter: fastSort ? "unsorted" : get().filter,
			fullscreen: fastSort ? false : get().fullscreen
		});
		scheduleSave(get);
	},
	setFullscreen: (fullscreen) => set({ fullscreen }),
	setThumbnailSize: (thumbnailSize) => {
		set({ thumbnailSize });
		scheduleSave(get);
	},
	setQualityAssist: (qualityAssist) => {
		set({ qualityAssist });
		scheduleSave(get);
	},
	setShowSimilar: (showSimilar) => set({ showSimilar }),
	setAutoAdvance: (autoAdvance) => set({ autoAdvance }),
	setZoom: (zoom) => set({
		zoom: Math.min(6, Math.max(1, zoom)),
		panX: zoom <= 1 ? 0 : get().panX,
		panY: zoom <= 1 ? 0 : get().panY
	}),
	nudgePan: (x, y) => set((s) => ({
		panX: s.panX + x,
		panY: s.panY + y
	})),
	resetView: () => set({
		zoom: 1,
		panX: 0,
		panY: 0
	}),
	actualSize: () => set({
		zoom: 1,
		panX: 0,
		panY: 0
	}),
	rotate: () => {
		const id = get().currentId;
		if (!id) return;
		set((s) => ({ photos: s.photos.map((p) => p.id === id ? {
			...p,
			rotation: (p.rotation + 90) % 360
		} : p) }));
		scheduleSave(get);
	},
	selectPhoto: (id) => {
		set({
			currentId: id,
			zoom: 1,
			panX: 0,
			panY: 0,
			previewError: null
		});
		queueMicrotask(() => {
			get().preloadNeighbors();
			get().analyzeCurrent();
		});
		scheduleSave(get);
	},
	step: (dir) => {
		const list = visibleList(get());
		if (!list.length) return;
		const i = indexOfId(list, get().currentId);
		const next = Math.min(list.length - 1, Math.max(0, i + dir));
		get().selectPhoto(list[next].id);
	},
	goFirst: () => {
		const list = visibleList(get());
		if (list[0]) get().selectPhoto(list[0].id);
	},
	goLast: () => {
		const list = visibleList(get());
		const last = list[list.length - 1];
		if (last) get().selectPhoto(last.id);
	},
	categorize: async (status, id) => {
		const state = get();
		if (state.conflict || state.fileError) return;
		const photoId = id ?? state.currentId;
		if (!photoId || !state.project) return;
		const photo = state.photos.find((p) => p.id === photoId);
		if (!photo) return;
		if (photo.status === status && state.autoAdvance) {
			get().step(1);
			return;
		}
		const existing = state.destNames[status];
		const result = await placePhoto({
			photo,
			status,
			project: state.project,
			blob: getBlob(photo.id),
			destHandles: state.destHandles,
			existingNames: existing,
			mode: state.project.mode
		});
		if (result.conflict) {
			set({ conflict: {
				photoId,
				filename: photo.filename,
				folder: status,
				status
			} });
			return;
		}
		if (!result.ok) {
			set({ fileError: {
				photoId,
				filename: photo.filename,
				reason: result.error ?? "Failed to process file"
			} });
			return;
		}
		if (result.skipped) return;
		const op = {
			type: "categorize",
			photoId,
			from: photo.status,
			to: status,
			fromDest: photo.destPath,
			toDest: result.destPath,
			fromDestName: photo.destFilename,
			toDestName: result.destFilename
		};
		set((s) => ({
			photos: s.photos.map((p) => p.id === photoId ? {
				...p,
				status,
				timestamp: Date.now(),
				destPath: result.destPath,
				destFilename: result.destFilename,
				error: null
			} : p),
			undo: [...s.undo, op].slice(-200),
			redo: []
		}));
		if (state.autoAdvance) {
			const nextState = get();
			const list = visibleList(nextState);
			const i = indexOfId(list, photoId);
			if (nextState.fastSort || nextState.filter === "unsorted") {
				const next = list[nextUnsortedIndex(list, i, 1)];
				if (next && next.id !== photoId) get().selectPhoto(next.id);
				else get().finishIfDone();
			} else {
				const next = list[Math.min(list.length - 1, i + 1)];
				if (next) get().selectPhoto(next.id);
			}
		}
		get().finishIfDone();
		scheduleSave(get);
	},
	resolveConflict: async (choice) => {
		const c = get().conflict;
		if (!c) return;
		const state = get();
		const photo = state.photos.find((p) => p.id === c.photoId);
		if (!photo || !state.project) {
			set({ conflict: null });
			return;
		}
		const result = await placePhoto({
			photo,
			status: c.status,
			project: state.project,
			blob: getBlob(photo.id),
			destHandles: state.destHandles,
			existingNames: state.destNames[c.status],
			mode: state.project.mode,
			conflictChoice: choice
		});
		set({ conflict: null });
		if (!result.ok) {
			set({ fileError: {
				photoId: photo.id,
				filename: photo.filename,
				reason: result.error ?? "Failed"
			} });
			return;
		}
		if (result.skipped) return;
		const op = {
			type: "categorize",
			photoId: photo.id,
			from: photo.status,
			to: c.status,
			fromDest: photo.destPath,
			toDest: result.destPath,
			fromDestName: photo.destFilename,
			toDestName: result.destFilename
		};
		set((s) => ({
			photos: s.photos.map((p) => p.id === photo.id ? {
				...p,
				status: c.status,
				timestamp: Date.now(),
				destPath: result.destPath,
				destFilename: result.destFilename,
				error: null
			} : p),
			undo: [...s.undo, op].slice(-200),
			redo: []
		}));
		if (state.autoAdvance) get().step(1);
		scheduleSave(get);
	},
	retryError: async () => {
		const err = get().fileError;
		if (!err) return;
		set({ fileError: null });
		const photo = get().photos.find((p) => p.id === err.photoId);
		if (!photo || photo.status === "unsorted") return;
		await get().categorize(photo.status, photo.id);
	},
	skipError: () => set({ fileError: null }),
	undoLast: () => {
		const state = get();
		const op = state.undo[state.undo.length - 1];
		if (!op) return;
		set((s) => ({
			photos: s.photos.map((p) => p.id === op.photoId ? {
				...p,
				status: op.from,
				destPath: op.fromDest,
				destFilename: op.fromDestName,
				timestamp: op.from === "unsorted" ? null : p.timestamp,
				error: null
			} : p),
			undo: s.undo.slice(0, -1),
			redo: [...s.redo, op],
			currentId: op.photoId
		}));
		scheduleSave(get);
	},
	redoLast: () => {
		const state = get();
		const op = state.redo[state.redo.length - 1];
		if (!op) return;
		set((s) => ({
			photos: s.photos.map((p) => p.id === op.photoId ? {
				...p,
				status: op.to,
				destPath: op.toDest,
				destFilename: op.toDestName,
				timestamp: Date.now(),
				error: null
			} : p),
			redo: s.redo.slice(0, -1),
			undo: [...s.undo, op],
			currentId: op.photoId
		}));
		scheduleSave(get);
	},
	jump: (filename) => {
		const hit = jumpToFile(get().photos, filename);
		if (!hit) {
			set({ jumpMiss: "File tidak ditemukan." });
			return false;
		}
		set({
			jumpMiss: null,
			jumpOpen: false,
			searchOpen: false,
			query: "",
			filter: "all"
		});
		get().selectPhoto(hit.id);
		return true;
	},
	openSearch: (searchOpen) => set({
		searchOpen,
		jumpMiss: null
	}),
	openJump: (jumpOpen) => set({
		jumpOpen,
		jumpMiss: null
	}),
	openSelected: (selectedOpen) => set({ selectedOpen }),
	openSettings: (settingsOpen) => set({ settingsOpen }),
	openShortcuts: (shortcutsOpen) => set({ shortcutsOpen }),
	openFolders: (foldersOpen) => set({ foldersOpen }),
	setPreviewError: (previewError) => set({ previewError }),
	exportReport: (kind) => {
		const { project, photos } = get();
		if (!project) return;
		const base = `${project.name}-report`;
		if (kind === "csv") downloadText(`${base}.csv`, buildCsv(photos), "text/csv");
		else downloadText(`${base}.json`, buildJson(project, photos), "application/json");
	},
	finishIfDone: () => {
		const { photos, view } = get();
		if (view !== "workspace") return;
		if (photos.length && photos.every((p) => p.status !== "unsorted")) {
			set({
				view: "complete",
				fastSort: false,
				fullscreen: false
			});
			scheduleSave(get);
		}
	},
	backToWorkspace: () => set({ view: "workspace" }),
	newSession: async () => {
		await clearSession();
		set({
			view: "home",
			project: null,
			photos: [],
			currentId: null,
			resumeAvailable: null,
			undo: [],
			redo: [],
			query: "",
			filter: "all",
			fastSort: false,
			conflict: null,
			fileError: null
		});
	},
	copyText: async (text) => {
		try {
			await navigator.clipboard.writeText(text);
		} catch {}
	},
	analyzeCurrent: async () => {
		const state = get();
		if (!state.qualityAssist) return;
		const photo = state.photos.find((p) => p.id === state.currentId);
		if (!photo || photo.quality) return;
		const q = await analyzePhoto(photo);
		if (!q) return;
		set((s) => {
			const similar = similarGroup(s.photos.map((p) => p.sourceKey === photo.sourceKey ? {
				...p,
				quality: p.quality ?? q
			} : p), {
				...photo,
				quality: q
			});
			const maxSim = similar[0] ? Math.max(...similar.map((x) => x.sourceKey === photo.sourceKey ? 100 : 90)) : 0;
			const quality = {
				...q,
				duplicateSimilarity: photo.isDemo ? similar.length ? 96 : 4 : maxSim
			};
			return { photos: s.photos.map((p) => p.sourceKey === photo.sourceKey && !p.quality ? {
				...p,
				quality
			} : p.id === photo.id ? {
				...p,
				quality
			} : p) };
		});
	},
	preloadNeighbors: () => {
		const list = visibleList(get());
		const i = indexOfId(list, get().currentId);
		for (const offset of [
			-1,
			0,
			1,
			2
		]) {
			const p = list[i + offset];
			if (p) preloadFull(p);
		}
	}
}));
function useCurrentPhoto() {
	return useSorter((s) => s.photos.find((p) => p.id === s.currentId) ?? null);
}
function useCounts() {
	return useSorter((s) => countByStatus(s.photos));
}
function useVisiblePhotos() {
	return useSorter((s) => applyFilter(s.photos, s.filter, s.query, s.sortOrder));
}
function currentPreviewUrl(photo) {
	if (!photo) return "";
	return objectUrlFor(photo);
}
async function filesFromList(list) {
	const files = Array.from(list);
	return {
		files,
		folder: files.find((f) => "webkitRelativePath" in f && f.webkitRelativePath)?.webkitRelativePath.split("/")[0] || files[0]?.name.split("/")[0] || "SOURCE"
	};
}
function HomeScreen() {
	const inputRef = (0, import_react.useRef)(null);
	const [dropping, setDropping] = (0, import_react.useState)(false);
	const resume = useSorter((s) => s.resumeAvailable);
	const prepareDemo = useSorter((s) => s.prepareDemo);
	const resumeSession = useSorter((s) => s.resumeSession);
	const declineResume = useSorter((s) => s.declineResume);
	const importFiles = useSorter((s) => s.importFiles);
	async function onFiles(list, folderHint) {
		const { files, folder } = await filesFromList(list);
		await importFiles(files, folderHint || folder);
	}
	async function onOpenFolder() {
		const picker = window.showDirectoryPicker;
		if (typeof picker === "function") try {
			const dir = await picker({ mode: "read" });
			const files = [];
			for await (const entry of dir.values()) if (entry.kind === "file") {
				const file = await entry.getFile();
				files.push(file);
			}
			await importFiles(files, dir.name);
			return;
		} catch (err) {
			if (err.name === "AbortError") return;
		}
		inputRef.current?.click();
	}
	const resumeCounts = resume?.project.isDemo ? Object.values(resume.statuses).reduce((acc, s) => {
		acc[s.status] += 1;
		return acc;
	}, {
		unsorted: 0,
		select: 0,
		alternative: 0,
		reject: 0
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col overflow-hidden bg-background",
		onDragOver: (e) => {
			e.preventDefault();
			setDropping(true);
		},
		onDragLeave: () => setDropping(false),
		onDrop: (e) => {
			e.preventDefault();
			setDropping(false);
			if (e.dataTransfer.files.length) onFiles(e.dataTransfer.files);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 film-grain opacity-60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex w-full max-w-5xl flex-1 flex-col px-5 py-8 sm:px-8 sm:py-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-9 items-center justify-center rounded-md border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApertureMark, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground",
							children: "Photo workflow"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-medium tracking-tight",
							children: "PHOTO SORTER"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-xs text-muted-foreground sm:block",
						children: "1 / 2 / 3 to cull"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid flex-1 items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-xl text-4xl font-medium leading-[1.1] tracking-[-0.03em] sm:text-5xl",
							children: "Cull thousands of frames without lifting the mouse."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground sm:text-base",
							children: "Built for photographers who come home with 5,000 files. Sort into SELECT, ALTERNATIVE, and REJECT. Auto-advance. Undo. Sessions that survive a crash."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								onClick: prepareDemo,
								children: [
									"Load ",
									DEMO_NAME,
									" demo"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								variant: "outline",
								onClick: () => void onOpenFolder(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }), "Open folder"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								"Demo is ",
								DEMO_COUNT.toLocaleString(),
								" photos from a festival shoot. Drop a folder of JPEG, PNG, WebP, TIFF, or RAW anytime."
							]
						}),
						resume ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 rounded-xl border border-border bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground",
									children: "Resume previous session?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm",
									children: [
										resume.project.name,
										" · ",
										resume.project.photoCount.toLocaleString(),
										" files"
									]
								}),
								resumeCounts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: [
										"Select ",
										Object.values(resume.statuses).filter((s) => s.status === "select").length,
										" · Alternative",
										" ",
										Object.values(resume.statuses).filter((s) => s.status === "alternative").length,
										" · Reject",
										" ",
										Object.values(resume.statuses).filter((s) => s.status === "reject").length
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: resumeSession,
										children: "Yes, resume"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: declineResume,
										children: "No"
									})]
								})
							]
						}) : null
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-1.5 rounded-xl border border-border bg-card p-2",
							children: DEMO_SOURCES.slice(0, 6).map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "aspect-[3/2] overflow-hidden rounded-md bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: src.url,
									alt: "",
									className: "h-full w-full object-cover"
								})
							}, src.key))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-3 gap-2 text-[11px] text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "mb-1 size-3.5" }), "Keyboard first"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "mb-1 size-3.5" }), "Virtualized list"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MousePointer2, { className: "mb-1 size-3.5" }), "Mouse optional"]
								})
							]
						})]
					})]
				})]
			}),
			dropping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center bg-background/80 text-sm tracking-wide",
				children: "Drop folder or photos to index"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*,.arw,.cr2,.cr3,.nef,.raf,.dng,.orf,.rw2",
				multiple: true,
				className: "hidden",
				onChange: (e) => {
					if (e.target.files?.length) onFiles(e.target.files);
					e.target.value = "";
				}
			})
		]
	});
}
function ApertureMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-4 text-primary",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "2.2",
				fill: "currentColor",
				stroke: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 4v3M12 17v3M4 12h3M17 12h3" })
		]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-9 w-full rounded-md border border-input bg-secondary px-3 py-1 text-sm text-foreground shadow-none transition-[box-shadow,border-color] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-xs font-medium tracking-wide text-muted-foreground", className),
	...props
}));
Label.displayName = Root.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border border-transparent bg-secondary transition-[background-color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring data-[state=checked]:bg-primary", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-4 rounded-full bg-foreground shadow-sm transition-transform duration-150 data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0.5 data-[state=checked]:bg-primary-foreground" })
}));
Switch.displayName = Switch$1.displayName;
function SetupScreen() {
	const project = useSorter((s) => s.project);
	const setFolders = useSorter((s) => s.setFolders);
	const setMode = useSorter((s) => s.setMode);
	const confirmStart = useSorter((s) => s.confirmStart);
	const newSession = useSorter((s) => s.newSession);
	const [moveOk, setMoveOk] = (0, import_react.useState)(false);
	if (!project) return null;
	const moveBlocked = project.mode === "move" && !moveOk;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-background px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-xl border border-border bg-card p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Before sorting"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "Confirm destinations"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: [project.photoCount.toLocaleString(), " photos indexed. Default mode is COPY so originals stay put."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Source",
							value: project.sourceFolder,
							onChange: (v) => setFolders({ sourceFolder: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Select",
							value: project.selectFolder,
							onChange: (v) => setFolders({ selectFolder: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Alternative",
							value: project.alternativeFolder,
							onChange: (v) => setFolders({ alternativeFolder: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Reject",
							value: project.rejectFolder,
							onChange: (v) => setFolders({ rejectFolder: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg border border-border px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "Mode"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: project.mode === "copy" ? "COPY — safe default" : "MOVE — relocates originals"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: project.mode === "move" ? "destructive" : "outline",
								size: "sm",
								onClick: () => setMode(project.mode === "copy" ? "move" : "copy"),
								children: project.mode.toUpperCase()
							})]
						}),
						project.mode === "move" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 rounded-lg border border-reject/40 bg-reject/5 px-3 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: moveOk,
								onCheckedChange: setMoveOk,
								className: "mt-0.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Move mode will change the original file location. I understand and want to continue." })]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => void newSession(),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: moveBlocked,
						onClick: confirmStart,
						children: "Start sorting"
					})]
				})
			]
		})
	});
}
function Field({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value,
			onChange: (e) => onChange(e.target.value)
		})]
	});
}
var Sheet = Dialog$1;
var SheetPortal = DialogPortal$1;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/70", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay$1.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "right", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed z-50 flex flex-col gap-4 bg-card p-5 text-card-foreground shadow-xl", side === "right" && "inset-y-0 right-0 h-full w-full max-w-md border-l border-border", side === "left" && "inset-y-0 left-0 h-full w-full max-w-sm border-r border-border", side === "bottom" && "inset-x-0 bottom-0 max-h-[80vh] rounded-t-xl border-t border-border", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 opacity-70 hover:opacity-100",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent$1.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-8", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-base font-medium", className),
	...props
}));
SheetTitle.displayName = DialogTitle$1.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription$1.displayName;
function Thumb({ photo, size, className }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		getThumbnail(photo, size).then((url) => {
			if (live) setSrc(url || null);
		});
		return () => {
			live = false;
		};
	}, [photo.sourceKey, size]);
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("bg-muted", className),
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: photo.filename,
		className: cn("h-full w-full object-cover", className),
		draggable: false,
		style: { transform: photo.rotation ? `rotate(${photo.rotation}deg)` : void 0 }
	});
}
function PhotoList({ photos }) {
	const parentRef = (0, import_react.useRef)(null);
	const currentId = useSorter((s) => s.currentId);
	const selectPhoto = useSorter((s) => s.selectPhoto);
	const thumb = useSorter((s) => s.thumbnailSize);
	const row = Math.max(64, thumb + 8);
	const virtualizer = useVirtualizer({
		count: photos.length,
		getScrollElement: () => parentRef.current,
		estimateSize: () => row,
		overscan: 14
	});
	const photosRef = (0, import_react.useRef)(photos);
	photosRef.current = photos;
	(0, import_react.useEffect)(() => {
		const i = photosRef.current.findIndex((p) => p.id === currentId);
		if (i >= 0) virtualizer.scrollToIndex(i, { align: "auto" });
	}, [currentId, virtualizer]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: parentRef,
		className: "h-full overflow-auto",
		"data-photo-list": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative w-full",
			style: { height: virtualizer.getTotalSize() },
			children: virtualizer.getVirtualItems().map((v) => {
				const photo = photos[v.index];
				const active = photo.id === currentId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectPhoto(photo.id),
					className: cn("absolute left-0 flex w-full items-center gap-2 px-2 text-left", active ? "bg-secondary" : "hover:bg-secondary/50"),
					style: {
						height: v.size,
						transform: `translateY(${v.start}px)`
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("overflow-hidden rounded-sm bg-muted", photo.status === "select" && "thumb-status-select", photo.status === "alternative" && "thumb-status-alternative", photo.status === "reject" && "thumb-status-reject"),
						style: {
							width: thumb,
							height: Math.round(thumb * .68)
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							photo,
							size: Math.round(thumb)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-mono text-[11px]",
							children: photo.filename
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[10px] uppercase tracking-wider text-muted-foreground",
							children: photo.status
						})]
					})]
				}, photo.id);
			})
		})
	});
}
function PhotoPreview({ fullscreen = false }) {
	const photo = useCurrentPhoto();
	const zoom = useSorter((s) => s.zoom);
	const panX = useSorter((s) => s.panX);
	const panY = useSorter((s) => s.panY);
	const previewError = useSorter((s) => s.previewError);
	const setZoom = useSorter((s) => s.setZoom);
	const nudgePan = useSorter((s) => s.nudgePan);
	const resetView = useSorter((s) => s.resetView);
	const rotate = useSorter((s) => s.rotate);
	const setPreviewError = useSorter((s) => s.setPreviewError);
	const setFullscreen = useSorter((s) => s.setFullscreen);
	const categorize = useSorter((s) => s.categorize);
	const selectPhoto = useSorter((s) => s.selectPhoto);
	const showSimilar = useSorter((s) => s.showSimilar);
	const photos = useSorter((s) => s.photos);
	const drag = (0, import_react.useRef)(null);
	if (!photo) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full items-center justify-center text-sm text-muted-foreground",
		children: "No photo in this view"
	});
	const src = currentPreviewUrl(photo);
	const similar = showSimilar && photo.quality ? similarGroup(photos, photo, 6) : photos.filter((p) => p.sourceKey === photo.sourceKey && p.id !== photo.id).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex h-full min-h-0 flex-col bg-background", fullscreen && "fixed inset-0 z-40"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-0 flex-1 overflow-hidden",
				onWheel: (e) => {
					e.preventDefault();
					setZoom(zoom + (e.deltaY < 0 ? .15 : -.15));
				},
				onDoubleClick: () => setZoom(zoom > 1 ? 1 : 2),
				onPointerDown: (e) => {
					if (zoom <= 1) return;
					e.target.setPointerCapture(e.pointerId);
					drag.current = {
						x: e.clientX,
						y: e.clientY
					};
				},
				onPointerMove: (e) => {
					if (!drag.current) return;
					nudgePan(e.clientX - drag.current.x, e.clientY - drag.current.y);
					drag.current = {
						x: e.clientX,
						y: e.clientY
					};
				},
				onPointerUp: () => {
					drag.current = null;
				},
				children: previewError || !src ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full flex-col items-center justify-center gap-3 px-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-8 text-reject" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Unable to preview image"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted-foreground",
							children: photo.filename
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: previewError ?? "Image could not be decoded."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => void categorize("reject"),
								children: "Mark reject"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => useSorter.getState().step(1),
								children: "Skip"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: photo.filename,
					onError: () => setPreviewError("Image could not be decoded."),
					className: "absolute left-1/2 top-1/2 max-h-none max-w-none select-none",
					style: {
						transform: `translate(-50%, -50%) translate(${panX}px, ${panY}px) scale(${zoom}) rotate(${photo.rotation}deg)`,
						height: zoom === 1 ? "100%" : void 0,
						width: zoom === 1 ? "100%" : void 0,
						objectFit: "contain"
					},
					draggable: false
				})
			}),
			similar.length > 0 && !fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: "Similar photos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1.5 overflow-x-auto",
					children: similar.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => selectPhoto(p.id),
						className: "h-12 w-16 shrink-0 overflow-hidden rounded-sm border border-border",
						title: p.filename,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							photo: p,
							size: 96
						})
					}, p.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1 border-t border-border px-2 py-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-3.5" }),
						label: "Zoom out",
						onClick: () => setZoom(zoom - .25)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-3.5" }),
						label: "Zoom in",
						onClick: () => setZoom(zoom + .25)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "h-7 px-2 text-[11px]",
						onClick: resetView,
						children: "Fit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "h-7 px-2 text-[11px]",
						onClick: () => setZoom(2),
						children: "Actual"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "size-3.5" }),
						label: "Rotate (R)",
						onClick: rotate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "h-7 px-2 text-[11px]",
						onClick: () => setFullscreen(!fullscreen),
						children: fullscreen ? "Exit" : "Full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto font-mono text-[11px] text-muted-foreground",
						children: [Math.round(zoom * 100), "%"]
					})
				]
			})
		]
	});
}
function Tool({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "icon",
		variant: "ghost",
		className: "size-7",
		onClick,
		title: label,
		"aria-label": label,
		children: icon
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.12em]", {
	variants: { variant: {
		default: "border-transparent bg-secondary text-muted-foreground",
		select: "border-transparent bg-select/15 text-select",
		maybe: "border-transparent bg-maybe/15 text-maybe",
		reject: "border-transparent bg-reject/15 text-reject",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root$1.displayName;
function InfoPanel() {
	const photo = useCurrentPhoto();
	const copyText = useSorter((s) => s.copyText);
	const qualityAssist = useSorter((s) => s.qualityAssist);
	if (!photo) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-4 text-sm text-muted-foreground",
		children: "Select a photo"
	});
	const q = photo.quality;
	function copy(label, value) {
		copyText(value);
		toast(label);
	}
	function openFile() {
		const url = currentPreviewUrl(photo);
		if (url) window.open(url, "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-auto p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
				children: "Information"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 break-all font-mono text-sm",
				children: photo.filename
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: photo.status })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Path",
						value: photo.destPath ?? photo.path
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Format",
						value: photo.format
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Resolution",
						value: formatRes(photo.width, photo.height)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "File size",
						value: formatBytes(photo.size)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Created",
						value: formatWhen(photo.createdAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Date taken",
						value: photo.dateTaken ?? "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
				children: "EXIF"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Camera",
						value: photo.camera ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Lens",
						value: photo.lens ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "ISO",
						value: photo.iso != null ? String(photo.iso) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Shutter",
						value: photo.shutter ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Aperture",
						value: photo.aperture ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						label: "Focal length",
						value: photo.focalLength ?? "—"
					})
				]
			}),
			qualityAssist ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: "Quality assist"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[11px] text-muted-foreground",
					children: "Advisory only — you decide the cull."
				}),
				q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Sharpness",
							value: q.sharpness.toUpperCase()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Exposure",
							value: q.exposure.replace("-", " ").toUpperCase()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Faces",
							value: q.faces == null ? "n/a" : String(q.faces)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Eyes",
							value: q.eyes.toUpperCase()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Duplicate similarity",
							value: `${q.duplicateSimilarity}%`
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted-foreground",
					children: "Analyzing…"
				})
			] }) : null,
			photo.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-reject",
				children: ["Failed: ", photo.error]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto grid gap-2 pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => copy("Filename copied", photo.filename),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), " Copy filename"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => copy("Path copied", photo.destPath ?? photo.path),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-3.5" }), " Copy path"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: openFile,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" }), " Open file"]
					})
				]
			})
		]
	});
}
function Row$1({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[10px] uppercase tracking-[0.14em] text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-0.5 break-all text-sm",
		children: value
	})] });
}
function StatusBadge({ status }) {
	if (status === "select") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "select",
		children: "Select"
	});
	if (status === "alternative") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "maybe",
		children: "Alternative"
	});
	if (status === "reject") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "reject",
		children: "Reject"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Unsorted" });
}
function SortBar({ compact = false }) {
	const categorize = useSorter((s) => s.categorize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid grid-cols-3 gap-2", compact ? "p-2" : "px-4 py-3"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
				k: "3",
				label: "Reject",
				hint: "D",
				className: "bg-reject/15 text-reject hover:bg-reject/25",
				onClick: () => void categorize("reject")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
				k: "2",
				label: "Alternative",
				hint: "A",
				className: "bg-maybe/15 text-maybe hover:bg-maybe/25",
				onClick: () => void categorize("alternative")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
				k: "1",
				label: "Select",
				hint: "S",
				className: "bg-select/15 text-select hover:bg-select/25",
				onClick: () => void categorize("select")
			})
		]
	});
}
function Cat({ k, label, hint, className, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "ghost",
			className: cn("h-11 rounded-lg font-medium", className),
			onClick,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mr-2 font-mono text-[11px] opacity-70",
				children: k
			}), label]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [
		label,
		" · ",
		k,
		" or ",
		hint
	] })] });
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$2, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-[transform] duration-200 ease-out",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = Root$2.displayName;
function StatusBar() {
	const counts = useCounts();
	const currentId = useSorter((s) => s.currentId);
	const visible = useVisiblePhotos();
	const sorted = counts.select + counts.alternative + counts.reject;
	const pct = counts.all ? sorted / counts.all * 100 : 0;
	const pos = visible.findIndex((p) => p.id === currentId) + 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 border-t border-border px-4 py-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-muted-foreground",
					children: [
						"Progress",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-foreground",
							children: [
								sorted.toLocaleString(),
								" / ",
								counts.all.toLocaleString()
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2",
							children: formatProgress(sorted, counts.all)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-muted-foreground",
					children: [
						"Viewing ",
						pos > 0 ? pos.toLocaleString() : "—",
						" / ",
						visible.length.toLocaleString()
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: pct }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-x-4 gap-y-1 font-mono text-[11px] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Select ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-select",
						children: counts.select.toLocaleString()
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Alternative ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-maybe",
						children: counts.alternative.toLocaleString()
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Reject ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-reject",
						children: counts.reject.toLocaleString()
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Unsorted ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: counts.unsorted.toLocaleString()
					})] })
				]
			})
		]
	});
}
function FastSort() {
	const photo = useCurrentPhoto();
	const setFastSort = useSorter((s) => s.setFastSort);
	const setFullscreen = useSorter((s) => s.setFullscreen);
	const fullscreen = useSorter((s) => s.fullscreen);
	const visible = useVisiblePhotos();
	const counts = useCounts();
	const currentId = useSorter((s) => s.currentId);
	const pos = visible.findIndex((p) => p.id === currentId) + 1;
	const sorted = counts.select + counts.alternative + counts.reject;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center gap-3 border-b border-border px-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Fast sort"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-mono text-sm",
						children: photo?.filename ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setFastSort(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-3.5" }), " Desk"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => setFastSort(false),
							"aria-label": "Close fast sort",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoPreview, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-sm",
					children: photo?.filename
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 tabular-nums text-xs text-muted-foreground",
					children: [
						pos.toLocaleString(),
						" / ",
						visible.length.toLocaleString(),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-2",
							children: "·"
						}),
						sorted.toLocaleString(),
						" / ",
						counts.all.toLocaleString(),
						" sorted (",
						formatProgress(sorted, counts.all),
						")"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {}),
			fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoPreview, { fullscreen: true }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "sr-only",
				onClick: () => setFullscreen(false),
				children: "Exit fullscreen"
			})
		]
	});
}
function Workspace() {
	const project = useSorter((s) => s.project);
	const fastSort = useSorter((s) => s.fastSort);
	const fullscreen = useSorter((s) => s.fullscreen);
	const filter = useSorter((s) => s.filter);
	const setFilter = useSorter((s) => s.setFilter);
	const query = useSorter((s) => s.query);
	const setQuery = useSorter((s) => s.setQuery);
	const jump = useSorter((s) => s.jump);
	const setFastSort = useSorter((s) => s.setFastSort);
	const openSettings = useSorter((s) => s.openSettings);
	const openSelected = useSorter((s) => s.openSelected);
	const openJump = useSorter((s) => s.openJump);
	const openShortcuts = useSorter((s) => s.openShortcuts);
	const openFolders = useSorter((s) => s.openFolders);
	const newSession = useSorter((s) => s.newSession);
	const visible = useVisiblePhotos();
	const counts = useCounts();
	const [listOpen, setListOpen] = (0, import_react.useState)(false);
	const [infoOpen, setInfoOpen] = (0, import_react.useState)(false);
	if (fastSort) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastSort, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center gap-2 border-b border-border px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-w-0 items-center gap-2",
					onClick: () => void newSession(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Photo Sorter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden truncate text-sm sm:inline",
						children: project?.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							className: "hidden sm:inline-flex",
							onClick: () => setFastSort(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-3.5" }), " Fast sort"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "sm:hidden",
							onClick: () => setFastSort(true),
							"aria-label": "Fast sort",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "lg:hidden",
							onClick: () => setListOpen(true),
							"aria-label": "Photo list",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "xl:hidden",
							onClick: () => setInfoOpen(true),
							"aria-label": "Information",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openJump(true),
							"aria-label": "Jump to file",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openSelected(true),
							"aria-label": "Find selected",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareCheckBig, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openFolders(true),
							"aria-label": "Open folders",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openSettings(true),
							"aria-label": "Settings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hidden w-64 shrink-0 flex-col border-r border-border lg:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-b border-border p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Search filename…",
									value: query,
									onChange: (e) => setQuery(e.target.value),
									onKeyDown: (e) => {
										if (e.key === "Enter") jump(query);
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterPills, {
								filter,
								counts,
								onChange: setFilter
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-h-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoList, { photos: visible })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "flex min-w-0 flex-1 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoPreview, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "hidden w-72 shrink-0 border-l border-border xl:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-t border-border px-3 py-1 text-[11px] text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hover:text-foreground",
					onClick: () => openShortcuts(true),
					children: "Keyboard ?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareStack, { className: "size-3" }),
						" ",
						project?.mode.toUpperCase()
					]
				})]
			}),
			fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoPreview, { fullscreen: true }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: listOpen,
				onOpenChange: setListOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "left",
					className: "p-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
							className: "p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Photos" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterPills, {
							filter,
							counts,
							onChange: setFilter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-[calc(100%-7rem)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoList, { photos: visible })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: infoOpen,
				onOpenChange: setInfoOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					className: "p-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, {})
				})
			})
		]
	});
}
function FilterPills({ filter, counts, onChange }) {
	const items = [
		{
			id: "all",
			label: "All",
			n: counts.all
		},
		{
			id: "select",
			label: "Select",
			n: counts.select
		},
		{
			id: "alternative",
			label: "Alt",
			n: counts.alternative
		},
		{
			id: "reject",
			label: "Reject",
			n: counts.reject
		},
		{
			id: "unsorted",
			label: "Unsorted",
			n: counts.unsorted
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1 border-b border-border p-2",
		children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onChange(it.id),
			className: cn("rounded-full px-2 py-1 text-[11px] tabular-nums", filter === it.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
			children: [
				it.label,
				" ",
				it.n.toLocaleString()
			]
		}, it.id))
	});
}
function CompleteScreen() {
	const counts = useCounts();
	const project = useSorter((s) => s.project);
	const backToWorkspace = useSorter((s) => s.backToWorkspace);
	const openSelected = useSorter((s) => s.openSelected);
	const openFolders = useSorter((s) => s.openFolders);
	const exportReport = useSorter((s) => s.exportReport);
	const newSession = useSorter((s) => s.newSession);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-background px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl border border-border bg-card p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Sorting complete"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-medium tracking-tight",
					children: "100% sorted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: project?.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 grid gap-2 font-mono text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Total",
							v: counts.all
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Select",
							v: counts.select,
							tone: "text-select"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Alternative",
							v: counts.alternative,
							tone: "text-maybe"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Reject",
							v: counts.reject,
							tone: "text-reject"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => openFolders(true),
							children: "Open destination folders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => openSelected(true),
							children: "View selected"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => exportReport("csv"),
								children: "Export CSV"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => exportReport("json"),
								children: "Export JSON"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: backToWorkspace,
							children: "Back to desk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => void newSession(),
							children: "New session"
						})
					]
				})
			]
		})
	});
}
function Row({ k, v, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: tone,
			children: v.toLocaleString()
		})]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/80", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-card p-6 text-card-foreground shadow-xl", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-left", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-medium tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-secondary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-3.5 rounded-full border border-primary bg-foreground shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
}));
Slider.displayName = Slider$1.displayName;
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/80", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-card p-6 text-card-foreground shadow-xl", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-2 text-left", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-medium", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function AppDialogs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JumpDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectedSheet, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortcutsDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldersDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConflictDialog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorDialog, {})
	] });
}
function SearchDialog() {
	const open = useSorter((s) => s.searchOpen);
	const query = useSorter((s) => s.query);
	const photos = useSorter((s) => s.photos);
	const setQuery = useSorter((s) => s.setQuery);
	const openSearch = useSorter((s) => s.openSearch);
	const jump = useSorter((s) => s.jump);
	const selectPhoto = useSorter((s) => s.selectPhoto);
	const inputRef = (0, import_react.useRef)(null);
	const hits = (0, import_react.useMemo)(() => searchPhotos(photos, query), [photos, query]);
	(0, import_react.useEffect)(() => {
		if (open) setTimeout(() => inputRef.current?.focus(), 20);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: openSearch,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Search filename" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Partial names, numbers, and extensions all work." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					ref: inputRef,
					placeholder: "IMG_1847",
					value: query,
					onChange: (e) => setQuery(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") {
							e.preventDefault();
							jump(query);
						}
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-64 overflow-auto rounded-md border border-border",
					children: query && hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-3 text-sm text-muted-foreground",
						children: "File tidak ditemukan."
					}) : hits.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-secondary",
						onClick: () => {
							selectPhoto(p.id);
							openSearch(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: p.filename
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-[10px] uppercase text-muted-foreground",
							children: p.status
						})]
					}, p.id))
				})
			]
		})
	});
}
function JumpDialog() {
	const open = useSorter((s) => s.jumpOpen);
	const miss = useSorter((s) => s.jumpMiss);
	const openJump = useSorter((s) => s.openJump);
	const jump = useSorter((s) => s.jump);
	const [value, setValue] = (0, import_react.useState)("");
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (open) {
			setValue("");
			setTimeout(() => ref.current?.focus(), 20);
		}
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: openJump,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Jump to file" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Enter a filename to highlight it in the list." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					ref,
					value,
					placeholder: "IMG_0187.JPG",
					onChange: (e) => setValue(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") {
							e.preventDefault();
							jump(value);
						}
					}
				}),
				miss ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-reject",
					children: miss
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => jump(value),
					children: "Jump"
				}) })
			]
		})
	});
}
function SelectedSheet() {
	const open = useSorter((s) => s.selectedOpen);
	const photos = useSorter((s) => s.photos);
	const openSelected = useSorter((s) => s.openSelected);
	const selectPhoto = useSorter((s) => s.selectPhoto);
	const copyText = useSorter((s) => s.copyText);
	const [active, setActive] = (0, import_react.useState)(null);
	const selected = photos.filter((p) => p.status === "select");
	const photo = photos.find((p) => p.id === active) ?? selected[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: openSelected,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Selected photos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [selected.length.toLocaleString(), " files marked SELECT."] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-auto",
				children: selected.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Nothing selected yet."
				}) : selected.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setActive(p.id);
						selectPhoto(p.id);
					},
					className: "flex w-full items-center gap-2 rounded-md px-1 py-1.5 text-left hover:bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-9 overflow-hidden rounded-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							photo: p,
							size: 72
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs",
						children: p.filename
					})]
				}, p.id))
			}),
			photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 border-t border-border pt-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: photo.filename
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: photo.status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all text-xs text-muted-foreground",
						children: photo.destPath ?? photo.path
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => selectPhoto(photo.id),
								children: "Preview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									const url = currentPreviewUrl(photo);
									if (url) window.open(url, "_blank", "noopener,noreferrer");
								},
								children: "Open file"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => {
									copyText(photo.filename);
									toast("Filename copied");
								},
								children: "Copy filename"
							})
						]
					})
				]
			}) : null
		] })
	});
}
function SettingsDialog() {
	const open = useSorter((s) => s.settingsOpen);
	const openSettings = useSorter((s) => s.openSettings);
	const thumb = useSorter((s) => s.thumbnailSize);
	const setThumb = useSorter((s) => s.setThumbnailSize);
	const quality = useSorter((s) => s.qualityAssist);
	const setQuality = useSorter((s) => s.setQualityAssist);
	const similar = useSorter((s) => s.showSimilar);
	const setSimilar = useSorter((s) => s.setShowSimilar);
	const auto = useSorter((s) => s.autoAdvance);
	const setAuto = useSorter((s) => s.setAutoAdvance);
	const sort = useSorter((s) => s.sortOrder);
	const setSort = useSorter((s) => s.setSort);
	const project = useSorter((s) => s.project);
	const setMode = useSorter((s) => s.setMode);
	const exportReport = useSorter((s) => s.exportReport);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: openSettings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Settings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Culling behaviour and list density." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Thumbnail size" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						className: "mt-3",
						min: 56,
						max: 140,
						step: 4,
						value: [thumb],
						onValueChange: (v) => setThumb(v[0] ?? 88)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] text-muted-foreground",
						children: thumb < 72 ? "Small" : thumb < 110 ? "Medium" : "Large"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowToggle, {
					label: "Auto-advance after 1 / 2 / 3",
					checked: auto,
					onChange: setAuto
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowToggle, {
					label: "Quality assist",
					checked: quality,
					onChange: setQuality
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowToggle, {
					label: "Similar photo strip",
					checked: similar,
					onChange: setSimilar
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Sort order" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "h-9 rounded-md border border-input bg-secondary px-3 text-sm",
						value: sort,
						onChange: (e) => setSort(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "filename-az",
								children: "Filename A–Z"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "filename-za",
								children: "Filename Z–A"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "date-taken",
								children: "Date taken"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "date-modified",
								children: "Date modified"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "file-size",
								children: "File size"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "camera",
								children: "Camera"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "focal-length",
								children: "Focal length"
							})
						]
					})]
				}),
				project ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "File mode" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setMode(project.mode === "copy" ? "move" : "copy"),
						children: project.mode.toUpperCase()
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => exportReport("csv"),
						children: "Export CSV"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => exportReport("json"),
						children: "Export JSON"
					})]
				})
			]
		})] })
	});
}
function RowToggle({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center justify-between gap-3 text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange
		})]
	});
}
function ShortcutsDialog() {
	const open = useSorter((s) => s.shortcutsOpen);
	const openShortcuts = useSorter((s) => s.openShortcuts);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: openShortcuts,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Keyboard" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Designed so the mouse is optional." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-2 text-sm",
			children: [
				["← →", "Previous / next"],
				["1 / S", "Select"],
				["2 / A", "Alternative"],
				["3 / D / Delete", "Reject"],
				["Space", "Zoom"],
				["F", "Fullscreen"],
				["R", "Rotate"],
				["Enter", "Confirm Select"],
				["Esc", "Close / exit Fast Sort"],
				["Ctrl Z", "Undo"],
				["Ctrl Shift Z", "Redo"],
				["Ctrl F", "Search"],
				["Ctrl G", "Jump to file"],
				["Home / End", "First / last"],
				["?", "This list"]
			].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted-foreground",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: v })]
			}, k))
		})] })
	});
}
function FoldersDialog() {
	const open = useSorter((s) => s.foldersOpen);
	const openFolders = useSorter((s) => s.openFolders);
	const project = useSorter((s) => s.project);
	const photos = useSorter((s) => s.photos);
	if (!project) return null;
	const groups = [
		{
			label: "Select",
			folder: project.selectFolder,
			list: photos.filter((p) => p.status === "select")
		},
		{
			label: "Alternative",
			folder: project.alternativeFolder,
			list: photos.filter((p) => p.status === "alternative")
		},
		{
			label: "Reject",
			folder: project.rejectFolder,
			list: photos.filter((p) => p.status === "reject")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: openFolders,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Destination folders" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: project.isDemo ? "Demo destinations are virtual. Export a report, or drop a real folder in a Chromium browser to copy files." : "Files are copied or moved into these folders when the browser allows it." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid max-h-80 gap-4 overflow-auto",
				children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-wider text-muted-foreground",
					children: [
						g.label,
						" · ",
						g.list.length
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs",
					children: g.folder
				})] }, g.label))
			})]
		})
	});
}
function ConflictDialog() {
	const conflict = useSorter((s) => s.conflict);
	const resolve = useSorter((s) => s.resolveConflict);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: Boolean(conflict),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "File already exists" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
			conflict?.filename,
			" is already in the ",
			conflict?.folder,
			" folder."
		] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void resolve("skip"),
				children: "Skip"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void resolve("replace"),
				children: "Replace"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void resolve("rename"),
				children: "Rename"
			})
		] })] })
	});
}
function ErrorDialog() {
	const err = useSorter((s) => s.fileError);
	const retry = useSorter((s) => s.retryError);
	const skip = useSorter((s) => s.skipError);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: Boolean(err),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: ["Failed to process ", err?.filename] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: ["Reason: ", err?.reason] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			onClick: skip,
			children: "Skip"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => void retry(),
			children: "Retry"
		})] })] })
	});
}
function KeyboardController() {
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const s = useSorter.getState();
			if (s.view !== "workspace" && s.view !== "complete") return;
			if (e.key === "Escape") {
				if (s.fullscreen) {
					s.setFullscreen(false);
					e.preventDefault();
					return;
				}
				if (s.searchOpen) {
					s.openSearch(false);
					e.preventDefault();
					return;
				}
				if (s.jumpOpen) {
					s.openJump(false);
					e.preventDefault();
					return;
				}
				if (s.selectedOpen) {
					s.openSelected(false);
					e.preventDefault();
					return;
				}
				if (s.settingsOpen) {
					s.openSettings(false);
					e.preventDefault();
					return;
				}
				if (s.shortcutsOpen) {
					s.openShortcuts(false);
					e.preventDefault();
					return;
				}
				if (s.foldersOpen) {
					s.openFolders(false);
					e.preventDefault();
					return;
				}
				if (s.fastSort) {
					s.setFastSort(false);
					e.preventDefault();
				}
				return;
			}
			if (s.conflict || s.fileError) return;
			if (isEditableTarget(e.target)) return;
			if (s.searchOpen || s.jumpOpen || s.settingsOpen) return;
			if (s.view !== "workspace") return;
			const ctrl = e.ctrlKey || e.metaKey;
			if (ctrl && e.key.toLowerCase() === "z") {
				e.preventDefault();
				if (e.shiftKey) s.redoLast();
				else s.undoLast();
				return;
			}
			if (ctrl && e.key.toLowerCase() === "f") {
				e.preventDefault();
				s.openSearch(true);
				return;
			}
			if (ctrl && e.key.toLowerCase() === "g") {
				e.preventDefault();
				s.openJump(true);
				return;
			}
			switch (e.key) {
				case "ArrowLeft":
					e.preventDefault();
					s.step(-1);
					break;
				case "ArrowRight":
					e.preventDefault();
					s.step(1);
					break;
				case "Home":
					e.preventDefault();
					s.goFirst();
					break;
				case "End":
					e.preventDefault();
					s.goLast();
					break;
				case "1":
				case "s":
				case "S":
					e.preventDefault();
					s.categorize("select");
					break;
				case "2":
				case "a":
				case "A":
					e.preventDefault();
					s.categorize("alternative");
					break;
				case "3":
				case "d":
				case "D":
				case "Delete":
					e.preventDefault();
					s.categorize("reject");
					break;
				case "Enter":
					e.preventDefault();
					s.categorize("select");
					break;
				case " ":
					e.preventDefault();
					s.setZoom(s.zoom > 1 ? 1 : 2);
					break;
				case "f":
				case "F":
					e.preventDefault();
					s.setFullscreen(!s.fullscreen);
					break;
				case "r":
				case "R":
					e.preventDefault();
					s.rotate();
					break;
				case "?":
					e.preventDefault();
					s.openShortcuts(true);
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return null;
}
function PhotoSorterApp() {
	const hydrated = useSorter((s) => s.hydrated);
	const view = useSorter((s) => s.view);
	const hydrate = useSorter((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground",
				children: "Photo Sorter"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Restoring session…"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyboardController, {}),
		view === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {}) : null,
		view === "setup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupScreen, {}) : null,
		view === "workspace" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workspace, {}) : null,
		view === "complete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompleteScreen, {}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDialogs, {})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSorterApp, {});
}
//#endregion
export { Home as component };
