import { createFileRoute } from "@tanstack/react-router";
import { PhotoSorterApp } from "@/components/app/photo-sorter-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PhotoSorterApp />;
}
