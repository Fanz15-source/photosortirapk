import { LayoutGrid, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PhotoPreview } from "@/components/app/photo-preview";
import { SortBar } from "@/components/app/sort-bar";
import { useCounts, useCurrentPhoto, useSorter, useVisiblePhotos } from "@/lib/store/sorter-store";
import { formatProgress } from "@/lib/format";

export function FastSort() {
  const photo = useCurrentPhoto();
  const setFastSort = useSorter((s) => s.setFastSort);
  const setFullscreen = useSorter((s) => s.setFullscreen);
  const fullscreen = useSorter((s) => s.fullscreen);
  const visible = useVisiblePhotos();
  const counts = useCounts();
  const currentId = useSorter((s) => s.currentId);
  const pos = visible.findIndex((p) => p.id === currentId) + 1;
  const sorted = counts.select + counts.alternative + counts.reject;

  return (
    <div className="flex h-dvh min-h-0 flex-col bg-background">
      <header className="flex h-12 shrink-0 items-center gap-3 border-b border-border px-3">
        <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Fast sort</p>
        <p className="truncate font-mono text-sm">{photo?.filename ?? "—"}</p>
        <div className="ml-auto flex items-center gap-1">
          <Button size="sm" variant="ghost" onClick={() => setFastSort(false)}>
            <LayoutGrid className="size-3.5" /> Desk
          </Button>
          <Button size="icon" variant="ghost" onClick={() => setFastSort(false)} aria-label="Close fast sort">
            <X className="size-4" />
          </Button>
        </div>
      </header>
      <div className="min-h-0 flex-1">
        <PhotoPreview minimal />
      </div>
      <div className="px-4 pt-3 text-center">
        <p className="font-mono text-sm">{photo?.filename}</p>
        <p className="mt-1 tabular-nums text-xs text-muted-foreground">
          {pos.toLocaleString()} / {visible.length.toLocaleString()}
          <span className="mx-2">·</span>
          {sorted.toLocaleString()} / {counts.all.toLocaleString()} sorted ({formatProgress(sorted, counts.all)})
        </p>
      </div>
      <SortBar />
      {fullscreen ? <PhotoPreview fullscreen /> : null}
    </div>
  );
}
