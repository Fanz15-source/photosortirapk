import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useSorter } from "@/lib/store/sorter-store";

export function SetupScreen() {
  const project = useSorter((s) => s.project);
  const setFolders = useSorter((s) => s.setFolders);
  const setMode = useSorter((s) => s.setMode);
  const confirmStart = useSorter((s) => s.confirmStart);
  const newSession = useSorter((s) => s.newSession);
  const [moveOk, setMoveOk] = useState(false);

  if (!project) return null;

  const moveBlocked = project.mode === "move" && !moveOk;

  return (
    <div className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-lg rounded-xl border border-border bg-card p-6 sm:p-8">
        <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Before sorting</p>
        <h1 className="mt-1 text-2xl font-medium tracking-tight">Confirm destinations</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {project.photoCount.toLocaleString()} photos indexed. Default mode is COPY so originals stay put.
        </p>

        <div className="mt-6 grid gap-4">
          <Field label="Source" value={project.sourceFolder} onChange={(v) => setFolders({ sourceFolder: v })} />
          <Field label="Select" value={project.selectFolder} onChange={(v) => setFolders({ selectFolder: v })} />
          <Field
            label="Alternative"
            value={project.alternativeFolder}
            onChange={(v) => setFolders({ alternativeFolder: v })}
          />
          <Field label="Reject" value={project.rejectFolder} onChange={(v) => setFolders({ rejectFolder: v })} />

          <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2.5">
            <div>
              <p className="text-sm">Mode</p>
              <p className="text-xs text-muted-foreground">{project.mode === "copy" ? "COPY — safe default" : "MOVE — relocates originals"}</p>
            </div>
            <Button
              variant={project.mode === "move" ? "destructive" : "outline"}
              size="sm"
              onClick={() => setMode(project.mode === "copy" ? "move" : "copy")}
            >
              {project.mode.toUpperCase()}
            </Button>
          </div>

          {project.mode === "move" ? (
            <label className="flex items-start gap-3 rounded-lg border border-reject/40 bg-reject/5 px-3 py-3 text-sm">
              <Switch checked={moveOk} onCheckedChange={setMoveOk} className="mt-0.5" />
              <span>
                Move mode will change the original file location. I understand and want to continue.
              </span>
            </label>
          ) : null}
        </div>

        <div className="mt-8 flex flex-col gap-2 sm:flex-row sm:justify-end">
          <Button variant="ghost" onClick={() => void newSession()}>
            Cancel
          </Button>
          <Button disabled={moveBlocked} onClick={confirmStart}>
            Start sorting
          </Button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
