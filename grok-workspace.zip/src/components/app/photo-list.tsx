import { useEffect, useRef } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { Thumb } from "@/components/app/thumb";
import { cn } from "@/lib/utils";
import type { Photo } from "@/lib/types";
import { useSorter } from "@/lib/store/sorter-store";

export function PhotoList({ photos }: { photos: Photo[] }) {
  const parentRef = useRef<HTMLDivElement>(null);
  const currentId = useSorter((s) => s.currentId);
  const selectPhoto = useSorter((s) => s.selectPhoto);
  const thumb = useSorter((s) => s.thumbnailSize);

  const row = Math.max(64, thumb + 8);
  const virtualizer = useVirtualizer({
    count: photos.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => row,
    overscan: 14,
  });

  const photosRef = useRef(photos);
  photosRef.current = photos;

  useEffect(() => {
    const i = photosRef.current.findIndex((p) => p.id === currentId);
    if (i >= 0) virtualizer.scrollToIndex(i, { align: "auto" });
  }, [currentId, virtualizer]);

  return (
    <div ref={parentRef} className="h-full overflow-auto" data-photo-list>
      <div className="relative w-full" style={{ height: virtualizer.getTotalSize() }}>
        {virtualizer.getVirtualItems().map((v) => {
          const photo = photos[v.index]!;
          const active = photo.id === currentId;
          return (
            <button
              key={photo.id}
              type="button"
              onClick={() => selectPhoto(photo.id)}
              className={cn(
                "absolute left-0 flex w-full items-center gap-2 px-2 text-left",
                active ? "bg-secondary" : "hover:bg-secondary/50",
              )}
              style={{ height: v.size, transform: `translateY(${v.start}px)` }}
            >
              <div
                className={cn(
                  "overflow-hidden rounded-sm bg-muted",
                  photo.status === "select" && "thumb-status-select",
                  photo.status === "alternative" && "thumb-status-alternative",
                  photo.status === "reject" && "thumb-status-reject",
                )}
                style={{ width: thumb, height: Math.round(thumb * 0.68) }}
              >
                <Thumb photo={photo} size={Math.round(thumb)} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-mono text-[11px]">{photo.filename}</p>
                <p className="truncate text-[10px] uppercase tracking-wider text-muted-foreground">
                  {photo.status}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
