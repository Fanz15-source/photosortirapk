import { Copy, FolderOpen, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { currentPreviewUrl, useCurrentPhoto, useSorter } from "@/lib/store/sorter-store";
import { formatBytes, formatRes, formatWhen } from "@/lib/format";

export function InfoPanel() {
  const photo = useCurrentPhoto();
  const copyText = useSorter((s) => s.copyText);
  const qualityAssist = useSorter((s) => s.qualityAssist);

  if (!photo) {
    return <div className="p-4 text-sm text-muted-foreground">Select a photo</div>;
  }

  const q = photo.quality;

  function copy(label: string, value: string) {
    void copyText(value);
    toast(label);
  }

  function openFile() {
    const url = currentPreviewUrl(photo);
    if (url) window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <div className="flex h-full flex-col overflow-auto p-4">
      <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">Information</p>
      <h2 className="mt-2 break-all font-mono text-sm">{photo.filename}</h2>
      <div className="mt-2">
        <StatusBadge status={photo.status} />
      </div>

      <div className="mt-4 grid gap-3">
        <Row label="Path" value={photo.destPath ?? photo.path} />
        <Row label="Format" value={photo.format} />
        <Row label="Resolution" value={formatRes(photo.width, photo.height)} />
        <Row label="File size" value={formatBytes(photo.size)} />
        <Row label="Created" value={formatWhen(photo.createdAt)} />
        <Row label="Date taken" value={photo.dateTaken ?? "—"} />
      </div>

      <Separator className="my-4" />
      <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">EXIF</p>
      <div className="mt-3 grid gap-3">
        <Row label="Camera" value={photo.camera ?? "—"} />
        <Row label="Lens" value={photo.lens ?? "—"} />
        <Row label="ISO" value={photo.iso != null ? String(photo.iso) : "—"} />
        <Row label="Shutter" value={photo.shutter ?? "—"} />
        <Row label="Aperture" value={photo.aperture ?? "—"} />
        <Row label="Focal length" value={photo.focalLength ?? "—"} />
      </div>

      {qualityAssist ? (
        <>
          <Separator className="my-4" />
          <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">Quality assist</p>
          <p className="mt-1 text-[11px] text-muted-foreground">Advisory only — you decide the cull.</p>
          {q ? (
            <div className="mt-3 grid gap-3">
              <Row label="Sharpness" value={q.sharpness.toUpperCase()} />
              <Row label="Exposure" value={q.exposure.replace("-", " ").toUpperCase()} />
              <Row label="Faces" value={q.faces == null ? "n/a" : String(q.faces)} />
              <Row label="Eyes" value={q.eyes.toUpperCase()} />
              <Row label="Duplicate similarity" value={`${q.duplicateSimilarity}%`} />
            </div>
          ) : (
            <p className="mt-3 text-xs text-muted-foreground">Analyzing…</p>
          )}
        </>
      ) : null}

      {photo.error ? (
        <p className="mt-4 text-xs text-reject">Failed: {photo.error}</p>
      ) : null}

      <div className="mt-auto grid gap-2 pt-6">
        <Button variant="outline" size="sm" onClick={() => copy("Filename copied", photo.filename)}>
          <Copy className="size-3.5" /> Copy filename
        </Button>
        <Button variant="outline" size="sm" onClick={() => copy("Path copied", photo.destPath ?? photo.path)}>
          <FolderOpen className="size-3.5" /> Copy path
        </Button>
        <Button variant="ghost" size="sm" onClick={openFile}>
          <ExternalLink className="size-3.5" /> Open file
        </Button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
      <p className="mt-0.5 break-all text-sm">{value}</p>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  if (status === "select") return <Badge variant="select">Select</Badge>;
  if (status === "alternative") return <Badge variant="maybe">Alternative</Badge>;
  if (status === "reject") return <Badge variant="reject">Reject</Badge>;
  return <Badge>Unsorted</Badge>;
}
