import { useState } from "react";
import {
  CheckSquare,
  FolderOpen,
  Gauge,
  Info,
  List,
  Search,
  Settings,
  SquareStack,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { PhotoList } from "@/components/app/photo-list";
import { PhotoPreview } from "@/components/app/photo-preview";
import { InfoPanel } from "@/components/app/info-panel";
import { SortBar } from "@/components/app/sort-bar";
import { StatusBar } from "@/components/app/status-bar";
import { FastSort } from "@/components/app/fast-sort";
import { useCounts, useSorter, useVisiblePhotos } from "@/lib/store/sorter-store";
import type { FilterId } from "@/lib/types";
import { cn } from "@/lib/utils";

export function Workspace() {
  const project = useSorter((s) => s.project);
  const fastSort = useSorter((s) => s.fastSort);
  const fullscreen = useSorter((s) => s.fullscreen);
  const filter = useSorter((s) => s.filter);
  const setFilter = useSorter((s) => s.setFilter);
  const query = useSorter((s) => s.query);
  const setQuery = useSorter((s) => s.setQuery);
  const jump = useSorter((s) => s.jump);
  const setFastSort = useSorter((s) => s.setFastSort);
  const openSettings = useSorter((s) => s.openSettings);
  const openSelected = useSorter((s) => s.openSelected);
  const openJump = useSorter((s) => s.openJump);
  const openShortcuts = useSorter((s) => s.openShortcuts);
  const openFolders = useSorter((s) => s.openFolders);
  const newSession = useSorter((s) => s.newSession);
  const visible = useVisiblePhotos();
  const counts = useCounts();
  const [listOpen, setListOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  if (fastSort) return <FastSort />;

  return (
    <div className="flex h-dvh min-h-0 flex-col bg-background">
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-3">
        <button type="button" className="flex min-w-0 items-center gap-2" onClick={() => void newSession()}>
          <span className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Photo Sorter</span>
          <span className="hidden truncate text-sm sm:inline">{project?.name}</span>
        </button>
        <div className="ml-auto flex items-center gap-1">
          <Button size="sm" variant="outline" className="hidden sm:inline-flex" onClick={() => setFastSort(true)}>
            <Gauge className="size-3.5" /> Fast sort
          </Button>
          <Button size="icon" variant="ghost" className="sm:hidden" onClick={() => setFastSort(true)} aria-label="Fast sort">
            <Gauge className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" className="lg:hidden" onClick={() => setListOpen(true)} aria-label="Photo list">
            <List className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" className="xl:hidden" onClick={() => setInfoOpen(true)} aria-label="Information">
            <Info className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => openJump(true)} aria-label="Jump to file">
            <Search className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => openSelected(true)} aria-label="Find selected">
            <CheckSquare className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => openFolders(true)} aria-label="Open folders">
            <FolderOpen className="size-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => openSettings(true)} aria-label="Settings">
            <Settings className="size-4" />
          </Button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-64 shrink-0 flex-col border-r border-border lg:flex">
          <div className="border-b border-border p-2">
            <Input
              placeholder="Search filename…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") jump(query);
              }}
            />
          </div>
          <FilterPills filter={filter} counts={counts} onChange={setFilter} />
          <div className="min-h-0 flex-1">
            <PhotoList photos={visible} />
          </div>
        </aside>

        <main className="flex min-w-0 flex-1 flex-col">
          <div className="min-h-0 flex-1">
            <PhotoPreview />
          </div>
          <SortBar />
        </main>

        <aside className="hidden w-72 shrink-0 border-l border-border xl:block">
          <InfoPanel />
        </aside>
      </div>

      <StatusBar />

      <div className="flex items-center justify-between border-t border-border px-3 py-1 text-[11px] text-muted-foreground">
        <button type="button" className="hover:text-foreground" onClick={() => openShortcuts(true)}>
          Keyboard ?
        </button>
        <span className="inline-flex items-center gap-1">
          <SquareStack className="size-3" /> {project?.mode.toUpperCase()}
        </span>
      </div>

      {fullscreen ? <PhotoPreview fullscreen /> : null}

      <Sheet open={listOpen} onOpenChange={setListOpen}>
        <SheetContent side="left" className="p-0">
          <SheetHeader className="p-4">
            <SheetTitle>Photos</SheetTitle>
          </SheetHeader>
          <FilterPills filter={filter} counts={counts} onChange={setFilter} />
          <div className="h-[calc(100%-7rem)]">
            <PhotoList photos={visible} />
          </div>
        </SheetContent>
      </Sheet>
      <Sheet open={infoOpen} onOpenChange={setInfoOpen}>
        <SheetContent className="p-0">
          <InfoPanel />
        </SheetContent>
      </Sheet>
    </div>
  );
}

function FilterPills({
  filter,
  counts,
  onChange,
}: {
  filter: FilterId;
  counts: ReturnType<typeof useCounts>;
  onChange: (f: FilterId) => void;
}) {
  const items: { id: FilterId; label: string; n: number }[] = [
    { id: "all", label: "All", n: counts.all },
    { id: "select", label: "Select", n: counts.select },
    { id: "alternative", label: "Alt", n: counts.alternative },
    { id: "reject", label: "Reject", n: counts.reject },
    { id: "unsorted", label: "Unsorted", n: counts.unsorted },
  ];
  return (
    <div className="flex flex-wrap gap-1 border-b border-border p-2">
      {items.map((it) => (
        <button
          key={it.id}
          type="button"
          onClick={() => onChange(it.id)}
          className={cn(
            "rounded-full px-2 py-1 text-[11px] tabular-nums",
            filter === it.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
          )}
        >
          {it.label} {it.n.toLocaleString()}
        </button>
      ))}
    </div>
  );
}
