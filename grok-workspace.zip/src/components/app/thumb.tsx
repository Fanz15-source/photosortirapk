import { useEffect, useState } from "react";
import type { Photo } from "@/lib/types";
import { getThumbnail } from "@/lib/thumbnail-engine";
import { cn } from "@/lib/utils";

export function Thumb({
  photo,
  size,
  className,
}: {
  photo: Photo;
  size: number;
  className?: string;
}) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    void getThumbnail(photo, size).then((url) => {
      if (live) setSrc(url || null);
    });
    return () => {
      live = false;
    };
  }, [photo.sourceKey, size]);

  if (!src) {
    return <div className={cn("bg-muted", className)} aria-hidden />;
  }

  return (
    <img
      src={src}
      alt=""
      className={cn("h-full w-full object-cover", className)}
      draggable={false}
      style={{ transform: photo.rotation ? `rotate(${photo.rotation}deg)` : undefined }}
    />
  );
}
