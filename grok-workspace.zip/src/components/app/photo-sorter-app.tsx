import { useEffect } from "react";
import { HomeScreen } from "@/components/app/home-screen";
import { SetupScreen } from "@/components/app/setup-screen";
import { Workspace } from "@/components/app/workspace";
import { CompleteScreen } from "@/components/app/complete-screen";
import { AppDialogs } from "@/components/app/app-dialogs";
import { KeyboardController } from "@/components/app/keyboard-controller";
import { useSorter } from "@/lib/store/sorter-store";

export function PhotoSorterApp() {
  const hydrated = useSorter((s) => s.hydrated);
  const view = useSorter((s) => s.view);
  const hydrate = useSorter((s) => s.hydrate);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  if (!hydrated) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground">Photo Sorter</p>
          <p className="mt-2 text-sm text-muted-foreground">Loading…</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <KeyboardController />
      {view === "home" ? <HomeScreen /> : null}
      {view === "setup" ? <SetupScreen /> : null}
      {view === "workspace" ? <Workspace /> : null}
      {view === "complete" ? <CompleteScreen /> : null}
      <AppDialogs />
    </>
  );
}
