import { useRef } from "react";
import { AlertTriangle, RotateCw, ZoomIn, ZoomOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Thumb } from "@/components/app/thumb";
import { currentPreviewUrl, useCurrentPhoto, useSorter } from "@/lib/store/sorter-store";
import { similarGroup } from "@/lib/quality-assist";
import { cn } from "@/lib/utils";

export function PhotoPreview({ fullscreen = false, minimal = false }: { fullscreen?: boolean; minimal?: boolean }) {
  const photo = useCurrentPhoto();
  const zoom = useSorter((s) => s.zoom);
  const panX = useSorter((s) => s.panX);
  const panY = useSorter((s) => s.panY);
  const previewError = useSorter((s) => s.previewError);
  const setZoom = useSorter((s) => s.setZoom);
  const nudgePan = useSorter((s) => s.nudgePan);
  const resetView = useSorter((s) => s.resetView);
  const rotate = useSorter((s) => s.rotate);
  const setPreviewError = useSorter((s) => s.setPreviewError);
  const setFullscreen = useSorter((s) => s.setFullscreen);
  const categorize = useSorter((s) => s.categorize);
  const selectPhoto = useSorter((s) => s.selectPhoto);
  const showSimilar = useSorter((s) => s.showSimilar);
  const photos = useSorter((s) => s.photos);
  const drag = useRef<{ x: number; y: number } | null>(null);

  if (!photo) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        No photo in this view
      </div>
    );
  }

  const src = currentPreviewUrl(photo);
  const similar = showSimilar && photo.quality ? similarGroup(photos, photo, 6) : photos.filter((p) => p.sourceKey === photo.sourceKey && p.id !== photo.id).slice(0, 6);

  return (
    <div className={cn("relative flex h-full min-h-0 flex-col bg-background", fullscreen && "fixed inset-0 z-40")}>
      <div
        className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden"
        onWheel={(e) => {
          e.preventDefault();
          setZoom(zoom + (e.deltaY < 0 ? 0.15 : -0.15));
        }}
        onDoubleClick={() => setZoom(zoom > 1 ? 1 : 2)}
        onPointerDown={(e) => {
          if (zoom <= 1) return;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          drag.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (!drag.current) return;
          nudgePan(e.clientX - drag.current.x, e.clientY - drag.current.y);
          drag.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
      >
        {previewError || !src ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <AlertTriangle className="size-8 text-reject" />
            <p className="text-sm font-medium">Unable to preview image</p>
            <p className="font-mono text-xs text-muted-foreground">{photo.filename}</p>
            <p className="text-xs text-muted-foreground">{previewError ?? "Image could not be decoded."}</p>
            <div className="mt-2 flex gap-2">
              <Button size="sm" variant="outline" onClick={() => void categorize("reject")}>
                Mark reject
              </Button>
              <Button size="sm" variant="ghost" onClick={() => useSorter.getState().step(1)}>
                Skip
              </Button>
            </div>
          </div>
        ) : (
          <img
            src={src}
            alt={photo.filename}
            onError={() => setPreviewError("Image could not be decoded.")}
            className="max-h-full max-w-full select-none object-contain"
            style={{
              transform: `translate(${panX}px, ${panY}px) scale(${zoom}) rotate(${photo.rotation}deg)`,
            }}
            draggable={false}
          />
        )}
      </div>

      {similar.length > 0 && !fullscreen && !minimal ? (
        <div className="border-t border-border px-3 py-2">
          <p className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">Similar photos</p>
          <div className="flex gap-1.5 overflow-x-auto">
            {similar.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => selectPhoto(p.id)}
                className="h-12 w-16 shrink-0 overflow-hidden rounded-sm border border-border"
                title={p.filename}
              >
                <Thumb photo={p} size={96} />
              </button>
            ))}
          </div>
        </div>
      ) : null}

      <div className="flex flex-wrap items-center gap-1 border-t border-border px-2 py-1.5">
        <Tool icon={<ZoomOut className="size-3.5" />} label="Zoom out" onClick={() => setZoom(zoom - 0.25)} />
        <Tool icon={<ZoomIn className="size-3.5" />} label="Zoom in" onClick={() => setZoom(zoom + 0.25)} />
        <Button size="sm" variant="ghost" className="h-7 px-2 text-[11px]" onClick={resetView}>
          Fit
        </Button>
        <Button size="sm" variant="ghost" className="h-7 px-2 text-[11px]" onClick={() => setZoom(2)}>
          Actual
        </Button>
        <Tool icon={<RotateCw className="size-3.5" />} label="Rotate (R)" onClick={rotate} />
        <Button size="sm" variant="ghost" className="h-7 px-2 text-[11px]" onClick={() => setFullscreen(!fullscreen)}>
          {fullscreen ? "Exit" : "Full"}
        </Button>
        <span className="ml-auto font-mono text-[11px] text-muted-foreground">{Math.round(zoom * 100)}%</span>
      </div>
    </div>
  );
}

function Tool({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <Button size="icon" variant="ghost" className="size-7" onClick={onClick} title={label} aria-label={label}>
      {icon}
    </Button>
  );
}
