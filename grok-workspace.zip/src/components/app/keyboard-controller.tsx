import { useEffect } from "react";
import { isEditableTarget } from "@/lib/utils";
import { useSorter } from "@/lib/store/sorter-store";

export function KeyboardController() {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const s = useSorter.getState();
      if (s.view !== "workspace" && s.view !== "complete") return;

      if (e.key === "Escape") {
        if (s.fullscreen) {
          s.setFullscreen(false);
          e.preventDefault();
          return;
        }
        if (s.searchOpen) {
          s.openSearch(false);
          e.preventDefault();
          return;
        }
        if (s.jumpOpen) {
          s.openJump(false);
          e.preventDefault();
          return;
        }
        if (s.selectedOpen) {
          s.openSelected(false);
          e.preventDefault();
          return;
        }
        if (s.settingsOpen) {
          s.openSettings(false);
          e.preventDefault();
          return;
        }
        if (s.shortcutsOpen) {
          s.openShortcuts(false);
          e.preventDefault();
          return;
        }
        if (s.foldersOpen) {
          s.openFolders(false);
          e.preventDefault();
          return;
        }
        if (s.fastSort) {
          s.setFastSort(false);
          e.preventDefault();
        }
        return;
      }

      if (s.conflict || s.fileError) return;
      if (isEditableTarget(e.target)) return;
      if (s.searchOpen || s.jumpOpen || s.settingsOpen) return;
      if (s.view !== "workspace") return;

      const ctrl = e.ctrlKey || e.metaKey;

      if (ctrl && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) s.redoLast();
        else s.undoLast();
        return;
      }
      if (ctrl && e.key.toLowerCase() === "f") {
        e.preventDefault();
        s.openSearch(true);
        return;
      }
      if (ctrl && e.key.toLowerCase() === "g") {
        e.preventDefault();
        s.openJump(true);
        return;
      }

      switch (e.key) {
        case "ArrowLeft":
          e.preventDefault();
          s.step(-1);
          break;
        case "ArrowRight":
          e.preventDefault();
          s.step(1);
          break;
        case "Home":
          e.preventDefault();
          s.goFirst();
          break;
        case "End":
          e.preventDefault();
          s.goLast();
          break;
        case "1":
        case "s":
        case "S":
          e.preventDefault();
          void s.categorize("select");
          break;
        case "2":
        case "a":
        case "A":
          e.preventDefault();
          void s.categorize("alternative");
          break;
        case "3":
        case "d":
        case "D":
        case "Delete":
          e.preventDefault();
          void s.categorize("reject");
          break;
        case "Enter":
          e.preventDefault();
          void s.categorize("select");
          break;
        case " ":
          e.preventDefault();
          s.setZoom(s.zoom > 1 ? 1 : 2);
          break;
        case "f":
        case "F":
          e.preventDefault();
          s.setFullscreen(!s.fullscreen);
          break;
        case "r":
        case "R":
          e.preventDefault();
          s.rotate();
          break;
        case "?":
          e.preventDefault();
          s.openShortcuts(true);
          break;
        default:
          break;
      }
    }

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return null;
}
