import { useRef, useState } from "react";
import { FolderOpen, Keyboard, Layers3, MousePointer2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEMO_COUNT, DEMO_NAME, DEMO_SOURCES } from "@/lib/demo/catalog";
import { useSorter } from "@/lib/store/sorter-store";

async function filesFromList(list: FileList | File[]): Promise<{ files: File[]; folder: string }> {
  const files = Array.from(list);
  const withPath = files.find((f) => "webkitRelativePath" in f && f.webkitRelativePath);
  const folder = withPath?.webkitRelativePath.split("/")[0] || files[0]?.name.split("/")[0] || "SOURCE";
  return { files, folder };
}

export function HomeScreen() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dropping, setDropping] = useState(false);
  const resume = useSorter((s) => s.resumeAvailable);
  const prepareDemo = useSorter((s) => s.prepareDemo);
  const resumeSession = useSorter((s) => s.resumeSession);
  const declineResume = useSorter((s) => s.declineResume);
  const importFiles = useSorter((s) => s.importFiles);

  async function onFiles(list: FileList | File[], folderHint?: string) {
    const { files, folder } = await filesFromList(list);
    await importFiles(files, folderHint || folder);
  }

  async function onOpenFolder() {
    const picker = window.showDirectoryPicker;
    if (typeof picker === "function") {
      try {
        const dir = await picker({ mode: "read" });
        const files: File[] = [];
        for await (const entry of dir.values()) {
          if (entry.kind === "file") {
            const file = await (entry as FileSystemFileHandle).getFile();
            files.push(file);
          }
        }
        await importFiles(files, dir.name);
        return;
      } catch (err) {
        if ((err as { name?: string }).name === "AbortError") return;
      }
    }
    inputRef.current?.click();
  }

  const resumeCounts = resume?.project.isDemo
    ? Object.values(resume.statuses).reduce(
        (acc, s) => {
          acc[s.status] += 1;
          return acc;
        },
        { unsorted: 0, select: 0, alternative: 0, reject: 0 },
      )
    : null;

  return (
    <div
      className="relative flex min-h-dvh flex-col overflow-hidden bg-background"
      onDragOver={(e) => {
        e.preventDefault();
        setDropping(true);
      }}
      onDragLeave={() => setDropping(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDropping(false);
        if (e.dataTransfer.files.length) void onFiles(e.dataTransfer.files);
      }}
    >
      <div className="pointer-events-none absolute inset-0 film-grain opacity-60" />
      <div className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col px-5 py-8 sm:px-8 sm:py-12">
        <header className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md border border-border">
              <ApertureMark />
            </div>
            <div>
              <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground">Photo workflow</p>
              <h1 className="text-lg font-medium tracking-tight">PHOTO SORTER</h1>
            </div>
          </div>
          <p className="hidden text-xs text-muted-foreground sm:block">1 / 2 / 3 to cull</p>
        </header>

        <div className="mt-10 grid flex-1 items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <h2 className="max-w-xl text-4xl font-medium leading-[1.1] tracking-[-0.03em] sm:text-5xl">
              Cull thousands of frames without lifting the mouse.
            </h2>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground sm:text-base">
              Built for photographers who come home with 5,000 files. Sort into SELECT, ALTERNATIVE, and REJECT. Auto-advance. Undo. Sessions that survive a crash.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button size="lg" onClick={prepareDemo}>
                Load {DEMO_NAME} demo
              </Button>
              <Button size="lg" variant="outline" onClick={() => void onOpenFolder()}>
                <FolderOpen className="size-4" />
                Open folder
              </Button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Demo is {DEMO_COUNT.toLocaleString()} photos from a festival shoot. Drop a folder of JPEG, PNG, WebP, TIFF, or RAW anytime.
            </p>

            {resume ? (
              <div className="mt-8 rounded-xl border border-border bg-card p-4">
                <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">Resume previous session?</p>
                <p className="mt-1 text-sm">
                  {resume.project.name} · {resume.project.photoCount.toLocaleString()} files
                </p>
                {resumeCounts ? (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Select {Object.values(resume.statuses).filter((s) => s.status === "select").length} · Alternative{" "}
                    {Object.values(resume.statuses).filter((s) => s.status === "alternative").length} · Reject{" "}
                    {Object.values(resume.statuses).filter((s) => s.status === "reject").length}
                  </p>
                ) : null}
                <div className="mt-3 flex gap-2">
                  <Button size="sm" onClick={resumeSession}>
                    Yes, resume
                  </Button>
                  <Button size="sm" variant="ghost" onClick={declineResume}>
                    No
                  </Button>
                </div>
              </div>
            ) : null}
          </div>

          <div className="relative">
            <div className="grid grid-cols-3 gap-1.5 rounded-xl border border-border bg-card p-2">
              {DEMO_SOURCES.slice(0, 6).map((src) => (
                <div key={src.key} className="aspect-[3/2] overflow-hidden rounded-md bg-muted">
                  <img src={src.url} alt="" className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-muted-foreground">
              <div className="rounded-lg border border-border bg-card px-3 py-2">
                <Keyboard className="mb-1 size-3.5" />
                Keyboard first
              </div>
              <div className="rounded-lg border border-border bg-card px-3 py-2">
                <Layers3 className="mb-1 size-3.5" />
                Virtualized list
              </div>
              <div className="rounded-lg border border-border bg-card px-3 py-2">
                <MousePointer2 className="mb-1 size-3.5" />
                Mouse optional
              </div>
            </div>
          </div>
        </div>
      </div>

      {dropping ? (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-background/80 text-sm tracking-wide">
          Drop folder or photos to index
        </div>
      ) : null}

      <input
        ref={inputRef}
        type="file"
        accept="image/*,.arw,.cr2,.cr3,.nef,.raf,.dng,.orf,.rw2"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) void onFiles(e.target.files);
          e.target.value = "";
        }}
      />
    </div>
  );
}

function ApertureMark() {
  return (
    <svg viewBox="0 0 24 24" className="size-4 text-primary" fill="none" stroke="currentColor" strokeWidth="1.6">
      <circle cx="12" cy="12" r="8" />
      <circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none" />
      <path d="M12 4v3M12 17v3M4 12h3M17 12h3" />
    </svg>
  );
}
