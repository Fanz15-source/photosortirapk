import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useSorter } from "@/lib/store/sorter-store";
import { cn } from "@/lib/utils";

export function SortBar({ compact = false }: { compact?: boolean }) {
  const categorize = useSorter((s) => s.categorize);

  return (
    <div className={cn("grid grid-cols-3 gap-2", compact ? "p-2" : "px-4 py-3")}>
      <Cat
        k="3"
        label="Reject"
        hint="D"
        className="bg-reject/15 text-reject hover:bg-reject/25"
        onClick={() => void categorize("reject")}
      />
      <Cat
        k="2"
        label="Alternative"
        hint="A"
        className="bg-maybe/15 text-maybe hover:bg-maybe/25"
        onClick={() => void categorize("alternative")}
      />
      <Cat
        k="1"
        label="Select"
        hint="S"
        className="bg-select/15 text-select hover:bg-select/25"
        onClick={() => void categorize("select")}
      />
    </div>
  );
}

function Cat({
  k,
  label,
  hint,
  className,
  onClick,
}: {
  k: string;
  label: string;
  hint: string;
  className: string;
  onClick: () => void;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button variant="ghost" className={cn("h-11 rounded-lg font-medium", className)} onClick={onClick}>
          <span className="mr-2 font-mono text-[11px] opacity-70">{k}</span>
          {label}
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        {label} · {k} or {hint}
      </TooltipContent>
    </Tooltip>
  );
}
