import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/app/info-panel";
import { Thumb } from "@/components/app/thumb";
import { useSorter } from "@/lib/store/sorter-store";
import { currentPreviewUrl } from "@/lib/store/sorter-store";
import { searchPhotos } from "@/lib/search";

export function AppDialogs() {
  return (
    <>
      <SearchDialog />
      <JumpDialog />
      <SelectedSheet />
      <SettingsDialog />
      <ShortcutsDialog />
      <FoldersDialog />
      <ConflictDialog />
      <ErrorDialog />
    </>
  );
}

function SearchDialog() {
  const open = useSorter((s) => s.searchOpen);
  const query = useSorter((s) => s.query);
  const photos = useSorter((s) => s.photos);
  const setQuery = useSorter((s) => s.setQuery);
  const openSearch = useSorter((s) => s.openSearch);
  const jump = useSorter((s) => s.jump);
  const selectPhoto = useSorter((s) => s.selectPhoto);
  const inputRef = useRef<HTMLInputElement>(null);
  const hits = useMemo(() => searchPhotos(photos, query), [photos, query]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 20);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={openSearch}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Search filename</DialogTitle>
          <DialogDescription>Partial names, numbers, and extensions all work.</DialogDescription>
        </DialogHeader>
        <Input
          ref={inputRef}
          placeholder="IMG_1847"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              jump(query);
            }
          }}
        />
        <div className="max-h-64 overflow-auto rounded-md border border-border">
          {query && hits.length === 0 ? (
            <p className="p-3 text-sm text-muted-foreground">File tidak ditemukan.</p>
          ) : (
            hits.map((p) => (
              <button
                key={p.id}
                type="button"
                className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-secondary"
                onClick={() => {
                  selectPhoto(p.id);
                  openSearch(false);
                }}
              >
                <span className="font-mono text-xs">{p.filename}</span>
                <span className="ml-auto text-[10px] uppercase text-muted-foreground">{p.status}</span>
              </button>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function JumpDialog() {
  const open = useSorter((s) => s.jumpOpen);
  const miss = useSorter((s) => s.jumpMiss);
  const openJump = useSorter((s) => s.openJump);
  const jump = useSorter((s) => s.jump);
  const [value, setValue] = useState("");
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setValue("");
      setTimeout(() => ref.current?.focus(), 20);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={openJump}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Jump to file</DialogTitle>
          <DialogDescription>Enter a filename to highlight it in the list.</DialogDescription>
        </DialogHeader>
        <Input
          ref={ref}
          value={value}
          placeholder="IMG_0187.JPG"
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              jump(value);
            }
          }}
        />
        {miss ? <p className="text-sm text-reject">{miss}</p> : null}
        <DialogFooter>
          <Button onClick={() => jump(value)}>Jump</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SelectedSheet() {
  const open = useSorter((s) => s.selectedOpen);
  const photos = useSorter((s) => s.photos);
  const openSelected = useSorter((s) => s.openSelected);
  const selectPhoto = useSorter((s) => s.selectPhoto);
  const copyText = useSorter((s) => s.copyText);
  const [active, setActive] = useState<string | null>(null);
  const selected = photos.filter((p) => p.status === "select");
  const photo = photos.find((p) => p.id === active) ?? selected[0];

  return (
    <Sheet open={open} onOpenChange={openSelected}>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Selected photos</SheetTitle>
          <SheetDescription>{selected.length.toLocaleString()} files marked SELECT.</SheetDescription>
        </SheetHeader>
        <div className="min-h-0 flex-1 overflow-auto">
          {selected.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nothing selected yet.</p>
          ) : (
            selected.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setActive(p.id);
                  selectPhoto(p.id);
                }}
                className="flex w-full items-center gap-2 rounded-md px-1 py-1.5 text-left hover:bg-secondary"
              >
                <div className="size-9 overflow-hidden rounded-sm">
                  <Thumb photo={p} size={72} />
                </div>
                <span className="font-mono text-xs">{p.filename}</span>
              </button>
            ))
          )}
        </div>
        {photo ? (
          <div className="grid gap-2 border-t border-border pt-3 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs">{photo.filename}</span>
              <StatusBadge status={photo.status} />
            </div>
            <p className="break-all text-xs text-muted-foreground">{photo.destPath ?? photo.path}</p>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={() => selectPhoto(photo.id)}>
                Preview
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  const url = currentPreviewUrl(photo);
                  if (url) window.open(url, "_blank", "noopener,noreferrer");
                }}
              >
                Open file
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  void copyText(photo.filename);
                  toast("Filename copied");
                }}
              >
                Copy filename
              </Button>
            </div>
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

function SettingsDialog() {
  const open = useSorter((s) => s.settingsOpen);
  const openSettings = useSorter((s) => s.openSettings);
  const thumb = useSorter((s) => s.thumbnailSize);
  const setThumb = useSorter((s) => s.setThumbnailSize);
  const quality = useSorter((s) => s.qualityAssist);
  const setQuality = useSorter((s) => s.setQualityAssist);
  const similar = useSorter((s) => s.showSimilar);
  const setSimilar = useSorter((s) => s.setShowSimilar);
  const auto = useSorter((s) => s.autoAdvance);
  const setAuto = useSorter((s) => s.setAutoAdvance);
  const sort = useSorter((s) => s.sortOrder);
  const setSort = useSorter((s) => s.setSort);
  const project = useSorter((s) => s.project);
  const setMode = useSorter((s) => s.setMode);
  const exportReport = useSorter((s) => s.exportReport);

  return (
    <Dialog open={open} onOpenChange={openSettings}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>Culling behaviour and list density.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-5">
          <div>
            <Label>Thumbnail size</Label>
            <Slider className="mt-3" min={56} max={140} step={4} value={[thumb]} onValueChange={(v) => setThumb(v[0] ?? 88)} />
            <p className="mt-1 text-[11px] text-muted-foreground">
              {thumb < 72 ? "Small" : thumb < 110 ? "Medium" : "Large"}
            </p>
          </div>
          <RowToggle label="Auto-advance after 1 / 2 / 3" checked={auto} onChange={setAuto} />
          <RowToggle label="Quality assist" checked={quality} onChange={setQuality} />
          <RowToggle label="Similar photo strip" checked={similar} onChange={setSimilar} />
          <div className="grid gap-1.5">
            <Label>Sort order</Label>
            <select
              className="h-9 rounded-md border border-input bg-secondary px-3 text-sm"
              value={sort}
              onChange={(e) => setSort(e.target.value as typeof sort)}
            >
              <option value="filename-az">Filename A–Z</option>
              <option value="filename-za">Filename Z–A</option>
              <option value="date-taken">Date taken</option>
              <option value="date-modified">Date modified</option>
              <option value="file-size">File size</option>
              <option value="camera">Camera</option>
              <option value="focal-length">Focal length</option>
            </select>
          </div>
          {project ? (
            <div className="flex items-center justify-between">
              <Label>File mode</Label>
              <Button size="sm" variant="outline" onClick={() => setMode(project.mode === "copy" ? "move" : "copy")}>
                {project.mode.toUpperCase()}
              </Button>
            </div>
          ) : null}
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => exportReport("csv")}>
              Export CSV
            </Button>
            <Button size="sm" variant="outline" onClick={() => exportReport("json")}>
              Export JSON
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RowToggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-3 text-sm">
      {label}
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  );
}

function ShortcutsDialog() {
  const open = useSorter((s) => s.shortcutsOpen);
  const openShortcuts = useSorter((s) => s.openShortcuts);
  const rows = [
    ["← →", "Previous / next"],
    ["1 / S", "Select"],
    ["2 / A", "Alternative"],
    ["3 / D / Delete", "Reject"],
    ["Space", "Zoom"],
    ["F", "Fullscreen"],
    ["R", "Rotate"],
    ["Enter", "Confirm Select"],
    ["Esc", "Close / exit Fast Sort"],
    ["Ctrl Z", "Undo"],
    ["Ctrl Shift Z", "Redo"],
    ["Ctrl F", "Search"],
    ["Ctrl G", "Jump to file"],
    ["Home / End", "First / last"],
    ["?", "This list"],
  ];
  return (
    <Dialog open={open} onOpenChange={openShortcuts}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Keyboard</DialogTitle>
          <DialogDescription>Designed so the mouse is optional.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-2 text-sm">
          {rows.map(([k, v]) => (
            <div key={k} className="flex items-center justify-between gap-4">
              <span className="font-mono text-xs text-muted-foreground">{k}</span>
              <span>{v}</span>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function FoldersDialog() {
  const open = useSorter((s) => s.foldersOpen);
  const openFolders = useSorter((s) => s.openFolders);
  const project = useSorter((s) => s.project);
  const photos = useSorter((s) => s.photos);
  if (!project) return null;
  const groups = [
    { label: "Select", folder: project.selectFolder, list: photos.filter((p) => p.status === "select") },
    { label: "Alternative", folder: project.alternativeFolder, list: photos.filter((p) => p.status === "alternative") },
    { label: "Reject", folder: project.rejectFolder, list: photos.filter((p) => p.status === "reject") },
  ];
  return (
    <Dialog open={open} onOpenChange={openFolders}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Destination folders</DialogTitle>
          <DialogDescription>
            {project.isDemo
              ? "Demo destinations are virtual. Export a report, or drop a real folder in a Chromium browser to copy files."
              : "Files are copied or moved into these folders when the browser allows it."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid max-h-80 gap-4 overflow-auto">
          {groups.map((g) => (
            <div key={g.label}>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">
                {g.label} · {g.list.length}
              </p>
              <p className="font-mono text-xs">{g.folder}</p>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ConflictDialog() {
  const conflict = useSorter((s) => s.conflict);
  const resolve = useSorter((s) => s.resolveConflict);
  return (
    <AlertDialog open={Boolean(conflict)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>File already exists</AlertDialogTitle>
          <AlertDialogDescription>
            {conflict?.filename} is already in the {conflict?.folder} folder.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <Button variant="outline" onClick={() => void resolve("skip")}>
            Skip
          </Button>
          <Button variant="outline" onClick={() => void resolve("replace")}>
            Replace
          </Button>
          <Button onClick={() => void resolve("rename")}>Rename</Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function ErrorDialog() {
  const err = useSorter((s) => s.fileError);
  const retry = useSorter((s) => s.retryError);
  const skip = useSorter((s) => s.skipError);
  return (
    <AlertDialog open={Boolean(err)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Failed to process {err?.filename}</AlertDialogTitle>
          <AlertDialogDescription>Reason: {err?.reason}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <Button variant="outline" onClick={skip}>
            Skip
          </Button>
          <Button onClick={() => void retry()}>Retry</Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
