import { Button } from "@/components/ui/button";
import { useCounts, useSorter } from "@/lib/store/sorter-store";

export function CompleteScreen() {
  const counts = useCounts();
  const project = useSorter((s) => s.project);
  const backToWorkspace = useSorter((s) => s.backToWorkspace);
  const openSelected = useSorter((s) => s.openSelected);
  const openFolders = useSorter((s) => s.openFolders);
  const exportReport = useSorter((s) => s.exportReport);
  const newSession = useSorter((s) => s.newSession);

  return (
    <div className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-md rounded-xl border border-border bg-card p-8">
        <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Sorting complete</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">100% sorted</h1>
        <p className="mt-1 text-sm text-muted-foreground">{project?.name}</p>

        <dl className="mt-6 grid gap-2 font-mono text-sm">
          <Row k="Total" v={counts.all} />
          <Row k="Select" v={counts.select} tone="text-select" />
          <Row k="Alternative" v={counts.alternative} tone="text-maybe" />
          <Row k="Reject" v={counts.reject} tone="text-reject" />
        </dl>

        <div className="mt-8 grid gap-2">
          <Button onClick={() => openFolders(true)}>Open destination folders</Button>
          <Button variant="outline" onClick={() => openSelected(true)}>
            View selected
          </Button>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={() => exportReport("csv")}>
              Export CSV
            </Button>
            <Button variant="outline" onClick={() => exportReport("json")}>
              Export JSON
            </Button>
          </div>
          <Button variant="ghost" onClick={backToWorkspace}>
            Back to desk
          </Button>
          <Button variant="ghost" onClick={() => void newSession()}>
            New session
          </Button>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v, tone }: { k: string; v: number; tone?: string }) {
  return (
    <div className="flex justify-between">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className={tone}>{v.toLocaleString()}</dd>
    </div>
  );
}
