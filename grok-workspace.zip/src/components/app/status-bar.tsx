import { Progress } from "@/components/ui/progress";
import { useCounts, useSorter } from "@/lib/store/sorter-store";
import { formatProgress } from "@/lib/format";
import { useVisiblePhotos } from "@/lib/store/sorter-store";

export function StatusBar() {
  const counts = useCounts();
  const currentId = useSorter((s) => s.currentId);
  const visible = useVisiblePhotos();
  const sorted = counts.select + counts.alternative + counts.reject;
  const pct = counts.all ? (sorted / counts.all) * 100 : 0;
  const pos = visible.findIndex((p) => p.id === currentId) + 1;

  return (
    <div className="flex flex-col gap-2 border-t border-border px-4 py-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <p className="tabular-nums text-muted-foreground">
          Progress{" "}
          <span className="text-foreground">
            {sorted.toLocaleString()} / {counts.all.toLocaleString()}
          </span>
          <span className="ml-2">{formatProgress(sorted, counts.all)}</span>
        </p>
        <p className="tabular-nums text-muted-foreground">
          Viewing {pos > 0 ? pos.toLocaleString() : "—"} / {visible.length.toLocaleString()}
        </p>
      </div>
      <Progress value={pct} />
      <div className="flex flex-wrap gap-x-4 gap-y-1 font-mono text-[11px] text-muted-foreground">
        <span>
          Select <span className="text-select">{counts.select.toLocaleString()}</span>
        </span>
        <span>
          Alternative <span className="text-maybe">{counts.alternative.toLocaleString()}</span>
        </span>
        <span>
          Reject <span className="text-reject">{counts.reject.toLocaleString()}</span>
        </span>
        <span>
          Unsorted <span className="text-foreground">{counts.unsorted.toLocaleString()}</span>
        </span>
      </div>
    </div>
  );
}
