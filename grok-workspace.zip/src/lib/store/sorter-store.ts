import { useMemo } from "react";
import { create } from "zustand";
import type {
  ConflictChoice,
  ConflictState,
  FileErrorState,
  FileMode,
  FilterId,
  HistoryOp,
  Photo,
  PhotoStatus,
  Project,
  SessionRecord,
  SortId,
  ViewMode,
} from "@/lib/types";
import { buildDemoCatalog, DEMO_COUNT, DEMO_NAME, DEMO_PROJECT_ID, DEMO_SOURCE } from "@/lib/demo/catalog";
import { applyFilter, countByStatus, nextUnsortedIndex } from "@/lib/filter";
import { jumpToFile } from "@/lib/search";
import { placePhoto, type DestHandles } from "@/lib/file-manager";
import { collectImageFiles, getBlob, indexFiles, objectUrlFor, readExif } from "@/lib/photo-engine";
import { analyzePhoto, similarGroup } from "@/lib/quality-assist";
import { preloadFull } from "@/lib/thumbnail-engine";
import { clearSession, loadSession, saveSession } from "@/lib/database/session-db";
import { buildCsv, buildJson, downloadText } from "@/lib/export/report";

const AUTO_SAVE_MS = 180;
const MAX_HISTORY = 200;

export interface SorterState {
  hydrated: boolean;
  view: ViewMode;
  resumeAvailable: SessionRecord | null;
  project: Project | null;
  photos: Photo[];
  currentId: string | null;
  filter: FilterId;
  query: string;
  sortOrder: SortId;
  fastSort: boolean;
  fullscreen: boolean;
  thumbnailSize: number;
  qualityAssist: boolean;
  showSimilar: boolean;
  autoAdvance: boolean;
  zoom: number;
  panX: number;
  panY: number;
  settingsOpen: boolean;
  searchOpen: boolean;
  jumpOpen: boolean;
  selectedOpen: boolean;
  shortcutsOpen: boolean;
  foldersOpen: boolean;
  previewError: string | null;
  conflict: ConflictState | null;
  fileError: FileErrorState | null;
  jumpMiss: string | null;
  undo: HistoryOp[];
  redo: HistoryOp[];
  destHandles: DestHandles;
  destNames: { select: Set<string>; alternative: Set<string>; reject: Set<string> };
  indexing: boolean;
  indexProgress: number;

  hydrate: () => Promise<void>;
  prepareDemo: () => void;
  confirmStart: () => void;
  declineResume: () => void;
  resumeSession: () => void;
  importFiles: (files: File[], folderName: string) => Promise<void>;
  setMode: (mode: FileMode) => void;
  setFolders: (partial: Partial<Pick<Project, "selectFolder" | "alternativeFolder" | "rejectFolder" | "sourceFolder" | "name">>) => void;
  setFilter: (filter: FilterId) => void;
  setQuery: (query: string) => void;
  setSort: (sort: SortId) => void;
  setFastSort: (on: boolean) => void;
  setFullscreen: (on: boolean) => void;
  setThumbnailSize: (n: number) => void;
  setQualityAssist: (on: boolean) => void;
  setShowSimilar: (on: boolean) => void;
  setAutoAdvance: (on: boolean) => void;
  setZoom: (z: number) => void;
  nudgePan: (x: number, y: number) => void;
  resetView: () => void;
  actualSize: () => void;
  rotate: () => void;
  selectPhoto: (id: string) => void;
  step: (dir: 1 | -1) => void;
  goFirst: () => void;
  goLast: () => void;
  categorize: (status: Exclude<PhotoStatus, "unsorted">, id?: string) => Promise<void>;
  resolveConflict: (choice: ConflictChoice) => Promise<void>;
  retryError: () => Promise<void>;
  skipError: () => void;
  undoLast: () => void;
  redoLast: () => void;
  jump: (filename: string) => boolean;
  openSearch: (open: boolean) => void;
  openJump: (open: boolean) => void;
  openSelected: (open: boolean) => void;
  openSettings: (open: boolean) => void;
  openShortcuts: (open: boolean) => void;
  openFolders: (open: boolean) => void;
  setPreviewError: (msg: string | null) => void;
  exportReport: (kind: "csv" | "json") => void;
  finishIfDone: () => void;
  backToWorkspace: () => void;
  newSession: () => Promise<void>;
  copyText: (text: string) => Promise<void>;
  analyzeCurrent: () => Promise<void>;
  preloadNeighbors: () => void;
}

let saveTimer: number | null = null;

function defaultProject(partial?: Partial<Project>): Project {
  return {
    id: DEMO_PROJECT_ID,
    name: DEMO_NAME,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    sourceFolder: DEMO_SOURCE,
    selectFolder: `${DEMO_SOURCE}/SELECT`,
    alternativeFolder: `${DEMO_SOURCE}/ALTERNATIVE`,
    rejectFolder: `${DEMO_SOURCE}/REJECT`,
    mode: "copy",
    isDemo: true,
    photoCount: DEMO_COUNT,
    ...partial,
  };
}

function applyStatuses(photos: Photo[], statuses: SessionRecord["statuses"]): Photo[] {
  return photos.map((p) => {
    const s = statuses[p.id];
    if (!s) return p;
    return {
      ...p,
      status: s.status,
      timestamp: s.timestamp,
      destPath: s.destPath,
      destFilename: s.destFilename,
      rotation: s.rotation,
      error: s.error,
    };
  });
}

function toSession(state: SorterState): SessionRecord | null {
  if (!state.project) return null;
  const statuses: SessionRecord["statuses"] = {};
  for (const p of state.photos) {
    if (p.status === "unsorted" && !p.rotation && !p.error) continue;
    statuses[p.id] = {
      status: p.status,
      timestamp: p.timestamp,
      destPath: p.destPath,
      destFilename: p.destFilename,
      rotation: p.rotation,
      error: p.error,
    };
  }
  return {
    project: { ...state.project, updatedAt: Date.now(), photoCount: state.photos.length },
    currentId: state.currentId,
    filter: state.filter,
    sortOrder: state.sortOrder,
    fastSort: state.fastSort,
    thumbnailSize: state.thumbnailSize,
    qualityAssist: state.qualityAssist,
    showSimilar: state.showSimilar,
    autoAdvance: state.autoAdvance,
    statuses,
    undo: state.undo,
    redo: state.redo,
  };
}

function scheduleSave(get: () => SorterState) {
  if (typeof window === "undefined") return;
  if (saveTimer) window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    const rec = toSession(get());
    if (rec) void saveSession(rec);
  }, AUTO_SAVE_MS);
}

function visibleList(state: Pick<SorterState, "photos" | "filter" | "query" | "sortOrder">): Photo[] {
  return applyFilter(state.photos, state.filter, state.query, state.sortOrder);
}

function idAt(list: Photo[], index: number): string | null {
  return list[index]?.id ?? null;
}

function indexOfId(list: Photo[], id: string | null): number {
  if (!id) return 0;
  const i = list.findIndex((p) => p.id === id);
  return i < 0 ? 0 : i;
}

export const useSorter = create<SorterState>((set, get) => ({
  hydrated: true,
  view: "home",
  resumeAvailable: null,
  project: null,
  photos: [],
  currentId: null,
  filter: "all",
  query: "",
  sortOrder: "filename-az",
  fastSort: false,
  fullscreen: false,
  thumbnailSize: 88,
  qualityAssist: true,
  showSimilar: true,
  autoAdvance: true,
  zoom: 1,
  panX: 0,
  panY: 0,
  settingsOpen: false,
  searchOpen: false,
  jumpOpen: false,
  selectedOpen: false,
  shortcutsOpen: false,
  foldersOpen: false,
  previewError: null,
  conflict: null,
  fileError: null,
  jumpMiss: null,
  undo: [],
  redo: [],
  destHandles: {},
  destNames: { select: new Set(), alternative: new Set(), reject: new Set() },
  indexing: false,
  indexProgress: 0,

  hydrate: async () => {
    const rec = await Promise.race([
      loadSession(),
      new Promise<null>((resolve) => {
        window.setTimeout(() => resolve(null), 600);
      }),
    ]);
    set({ hydrated: true, resumeAvailable: rec });
  },

  prepareDemo: () => {
    const project = defaultProject();
    set({
      view: "setup",
      project,
      photos: [],
      resumeAvailable: null,
      conflict: null,
      fileError: null,
    });
  },

  confirmStart: () => {
    const state = get();
    const project = state.project ?? defaultProject();
    let photos = state.photos;
    if (project.isDemo && photos.length === 0) {
      photos = buildDemoCatalog();
    }
    const currentId = photos[0]?.id ?? null;
    set({
      view: "workspace",
      project: { ...project, photoCount: photos.length },
      photos,
      currentId,
      filter: "all",
      fastSort: false,
      zoom: 1,
      panX: 0,
      panY: 0,
      undo: [],
      redo: [],
      destNames: { select: new Set(), alternative: new Set(), reject: new Set() },
    });
    scheduleSave(get);
    queueMicrotask(() => {
      get().preloadNeighbors();
      void get().analyzeCurrent();
    });
  },

  declineResume: () => set({ resumeAvailable: null }),

  resumeSession: () => {
    const rec = get().resumeAvailable;
    if (!rec) return;
    const photos = rec.project.isDemo
      ? applyStatuses(buildDemoCatalog(), rec.statuses)
      : get().photos.length
        ? applyStatuses(get().photos, rec.statuses)
        : [];
    if (rec.project.isDemo || photos.length) {
      set({
        view: "workspace",
        project: rec.project,
        photos,
        currentId: rec.currentId ?? photos[0]?.id ?? null,
        filter: rec.filter,
        sortOrder: rec.sortOrder,
        fastSort: rec.fastSort,
        thumbnailSize: rec.thumbnailSize,
        qualityAssist: rec.qualityAssist,
        showSimilar: rec.showSimilar,
        autoAdvance: rec.autoAdvance,
        undo: rec.undo,
        redo: rec.redo,
        resumeAvailable: null,
        zoom: 1,
        panX: 0,
        panY: 0,
      });
      scheduleSave(get);
      queueMicrotask(() => {
        get().preloadNeighbors();
        void get().analyzeCurrent();
      });
      return;
    }
    set({
      view: "home",
      resumeAvailable: rec,
    });
  },

  importFiles: async (files, folderName) => {
    set({ indexing: true, indexProgress: 0 });
    const images = collectImageFiles(files);
    const photos = await indexFiles(images, folderName || "SOURCE");
    const project = defaultProject({
      id: `proj-${Date.now()}`,
      name: folderName || "Untitled",
      sourceFolder: folderName || "SOURCE",
      selectFolder: `${folderName || "SOURCE"}/SELECT`,
      alternativeFolder: `${folderName || "SOURCE"}/ALTERNATIVE`,
      rejectFolder: `${folderName || "SOURCE"}/REJECT`,
      isDemo: false,
      photoCount: photos.length,
    });
    set({
      indexing: false,
      indexProgress: 1,
      project,
      photos,
      view: "setup",
      currentId: photos[0]?.id ?? null,
    });
    void (async () => {
      for (let i = 0; i < Math.min(photos.length, 40); i++) {
        const extra = await readExif(photos[i]!);
        if (Object.keys(extra).length) {
          set((s) => ({
            photos: s.photos.map((p) => (p.id === photos[i]!.id ? { ...p, ...extra } : p)),
          }));
        }
      }
    })();
  },

  setMode: (mode) =>
    set((s) => ({ project: s.project ? { ...s.project, mode } : s.project })),

  setFolders: (partial) =>
    set((s) => ({ project: s.project ? { ...s.project, ...partial } : s.project })),

  setFilter: (filter) => {
    set({ filter });
    const list = visibleList(get());
    if (!list.find((p) => p.id === get().currentId)) {
      set({ currentId: list[0]?.id ?? null, zoom: 1, panX: 0, panY: 0, previewError: null });
    }
    scheduleSave(get);
  },

  setQuery: (query) => {
    set({ query, jumpMiss: null });
    const list = visibleList(get());
    if (query && list.length && !list.find((p) => p.id === get().currentId)) {
      set({ currentId: list[0]?.id ?? null });
    }
  },

  setSort: (sortOrder) => {
    set({ sortOrder });
    scheduleSave(get);
  },

  setFastSort: (fastSort) => {
    set({
      fastSort,
      filter: fastSort ? "unsorted" : get().filter,
      fullscreen: fastSort ? false : get().fullscreen,
    });
    scheduleSave(get);
  },

  setFullscreen: (fullscreen) => set({ fullscreen }),
  setThumbnailSize: (thumbnailSize) => {
    set({ thumbnailSize });
    scheduleSave(get);
  },
  setQualityAssist: (qualityAssist) => {
    set({ qualityAssist });
    scheduleSave(get);
  },
  setShowSimilar: (showSimilar) => set({ showSimilar }),
  setAutoAdvance: (autoAdvance) => set({ autoAdvance }),
  setZoom: (zoom) => set({ zoom: Math.min(6, Math.max(1, zoom)), panX: zoom <= 1 ? 0 : get().panX, panY: zoom <= 1 ? 0 : get().panY }),
  nudgePan: (x, y) => set((s) => ({ panX: s.panX + x, panY: s.panY + y })),
  resetView: () => set({ zoom: 1, panX: 0, panY: 0 }),
  actualSize: () => set({ zoom: 1, panX: 0, panY: 0, /* fit handled in preview */ }),
  rotate: () => {
    const id = get().currentId;
    if (!id) return;
    set((s) => ({
      photos: s.photos.map((p) => (p.id === id ? { ...p, rotation: (p.rotation + 90) % 360 } : p)),
    }));
    scheduleSave(get);
  },

  selectPhoto: (id) => {
    set({ currentId: id, zoom: 1, panX: 0, panY: 0, previewError: null });
    queueMicrotask(() => {
      get().preloadNeighbors();
      void get().analyzeCurrent();
    });
    scheduleSave(get);
  },

  step: (dir) => {
    const list = visibleList(get());
    if (!list.length) return;
    const i = indexOfId(list, get().currentId);
    const next = Math.min(list.length - 1, Math.max(0, i + dir));
    get().selectPhoto(list[next]!.id);
  },

  goFirst: () => {
    const list = visibleList(get());
    if (list[0]) get().selectPhoto(list[0].id);
  },
  goLast: () => {
    const list = visibleList(get());
    const last = list[list.length - 1];
    if (last) get().selectPhoto(last.id);
  },

  categorize: async (status, id) => {
    const state = get();
    if (state.conflict || state.fileError) return;
    const photoId = id ?? state.currentId;
    if (!photoId || !state.project) return;
    const photo = state.photos.find((p) => p.id === photoId);
    if (!photo) return;
    if (photo.status === status && state.autoAdvance) {
      get().step(1);
      return;
    }

    const existing = state.destNames[status];
    const result = await placePhoto({
      photo,
      status,
      project: state.project,
      blob: getBlob(photo.id),
      destHandles: state.destHandles,
      existingNames: existing,
      mode: state.project.mode,
    });

    if (result.conflict) {
      set({ conflict: { photoId, filename: photo.filename, folder: status, status } });
      return;
    }
    if (!result.ok) {
      set({
        fileError: { photoId, filename: photo.filename, reason: result.error ?? "Failed to process file" },
      });
      return;
    }
    if (result.skipped) return;

    const op: HistoryOp = {
      type: "categorize",
      photoId,
      from: photo.status,
      to: status,
      fromDest: photo.destPath,
      toDest: result.destPath,
      fromDestName: photo.destFilename,
      toDestName: result.destFilename,
    };

    set((s) => ({
      photos: s.photos.map((p) =>
        p.id === photoId
          ? {
              ...p,
              status,
              timestamp: Date.now(),
              destPath: result.destPath,
              destFilename: result.destFilename,
              error: null,
            }
          : p,
      ),
      undo: [...s.undo, op].slice(-MAX_HISTORY),
      redo: [],
    }));

    if (state.autoAdvance) {
      const nextState = get();
      const list = visibleList(nextState);
      const i = indexOfId(list, photoId);
      if (nextState.fastSort || nextState.filter === "unsorted") {
        const ni = nextUnsortedIndex(list, i, 1);
        const next = list[ni];
        if (next && next.id !== photoId) get().selectPhoto(next.id);
        else get().finishIfDone();
      } else {
        const next = list[Math.min(list.length - 1, i + 1)];
        if (next) get().selectPhoto(next.id);
      }
    }

    get().finishIfDone();
    scheduleSave(get);
  },

  resolveConflict: async (choice) => {
    const c = get().conflict;
    if (!c) return;
    const state = get();
    const photo = state.photos.find((p) => p.id === c.photoId);
    if (!photo || !state.project) {
      set({ conflict: null });
      return;
    }
    const result = await placePhoto({
      photo,
      status: c.status,
      project: state.project,
      blob: getBlob(photo.id),
      destHandles: state.destHandles,
      existingNames: state.destNames[c.status],
      mode: state.project.mode,
      conflictChoice: choice,
    });
    set({ conflict: null });
    if (!result.ok) {
      set({ fileError: { photoId: photo.id, filename: photo.filename, reason: result.error ?? "Failed" } });
      return;
    }
    if (result.skipped) return;
    const op: HistoryOp = {
      type: "categorize",
      photoId: photo.id,
      from: photo.status,
      to: c.status,
      fromDest: photo.destPath,
      toDest: result.destPath,
      fromDestName: photo.destFilename,
      toDestName: result.destFilename,
    };
    set((s) => ({
      photos: s.photos.map((p) =>
        p.id === photo.id
          ? {
              ...p,
              status: c.status,
              timestamp: Date.now(),
              destPath: result.destPath,
              destFilename: result.destFilename,
              error: null,
            }
          : p,
      ),
      undo: [...s.undo, op].slice(-MAX_HISTORY),
      redo: [],
    }));
    if (state.autoAdvance) get().step(1);
    scheduleSave(get);
  },

  retryError: async () => {
    const err = get().fileError;
    if (!err) return;
    set({ fileError: null });
    const photo = get().photos.find((p) => p.id === err.photoId);
    if (!photo || photo.status === "unsorted") return;
    await get().categorize(photo.status as Exclude<PhotoStatus, "unsorted">, photo.id);
  },

  skipError: () => set({ fileError: null }),

  undoLast: () => {
    const state = get();
    const op = state.undo[state.undo.length - 1];
    if (!op) return;
    set((s) => ({
      photos: s.photos.map((p) =>
        p.id === op.photoId
          ? {
              ...p,
              status: op.from,
              destPath: op.fromDest,
              destFilename: op.fromDestName,
              timestamp: op.from === "unsorted" ? null : p.timestamp,
              error: null,
            }
          : p,
      ),
      undo: s.undo.slice(0, -1),
      redo: [...s.redo, op],
      currentId: op.photoId,
    }));
    scheduleSave(get);
  },

  redoLast: () => {
    const state = get();
    const op = state.redo[state.redo.length - 1];
    if (!op) return;
    set((s) => ({
      photos: s.photos.map((p) =>
        p.id === op.photoId
          ? {
              ...p,
              status: op.to,
              destPath: op.toDest,
              destFilename: op.toDestName,
              timestamp: Date.now(),
              error: null,
            }
          : p,
      ),
      redo: s.redo.slice(0, -1),
      undo: [...s.undo, op],
      currentId: op.photoId,
    }));
    scheduleSave(get);
  },

  jump: (filename) => {
    const hit = jumpToFile(get().photos, filename);
    if (!hit) {
      set({ jumpMiss: "File tidak ditemukan." });
      return false;
    }
    set({ jumpMiss: null, jumpOpen: false, searchOpen: false, query: "", filter: "all" });
    get().selectPhoto(hit.id);
    return true;
  },

  openSearch: (searchOpen) => set({ searchOpen, jumpMiss: null }),
  openJump: (jumpOpen) => set({ jumpOpen, jumpMiss: null }),
  openSelected: (selectedOpen) => set({ selectedOpen }),
  openSettings: (settingsOpen) => set({ settingsOpen }),
  openShortcuts: (shortcutsOpen) => set({ shortcutsOpen }),
  openFolders: (foldersOpen) => set({ foldersOpen }),
  setPreviewError: (previewError) => set({ previewError }),

  exportReport: (kind) => {
    const { project, photos } = get();
    if (!project) return;
    const base = `${project.name}-report`;
    if (kind === "csv") downloadText(`${base}.csv`, buildCsv(photos), "text/csv");
    else downloadText(`${base}.json`, buildJson(project, photos), "application/json");
  },

  finishIfDone: () => {
    const { photos, view } = get();
    if (view !== "workspace") return;
    if (photos.length && photos.every((p) => p.status !== "unsorted")) {
      set({ view: "complete", fastSort: false, fullscreen: false });
      scheduleSave(get);
    }
  },

  backToWorkspace: () => set({ view: "workspace" }),

  newSession: async () => {
    await clearSession();
    set({
      view: "home",
      project: null,
      photos: [],
      currentId: null,
      resumeAvailable: null,
      undo: [],
      redo: [],
      query: "",
      filter: "all",
      fastSort: false,
      conflict: null,
      fileError: null,
    });
  },

  copyText: async (text) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      /* ignore */
    }
  },

  analyzeCurrent: async () => {
    const state = get();
    if (!state.qualityAssist) return;
    const photo = state.photos.find((p) => p.id === state.currentId);
    if (!photo || photo.quality) return;
    const q = await analyzePhoto(photo);
    if (!q) return;
    set((s) => {
      const similar = similarGroup(
        s.photos.map((p) => (p.sourceKey === photo.sourceKey ? { ...p, quality: p.quality ?? q } : p)),
        { ...photo, quality: q },
      );
      const maxSim = similar[0] ? Math.max(...similar.map((x) => (x.sourceKey === photo.sourceKey ? 100 : 90))) : 0;
      const quality = { ...q, duplicateSimilarity: photo.isDemo ? (similar.length ? 96 : 4) : maxSim };
      return {
        photos: s.photos.map((p) =>
          p.sourceKey === photo.sourceKey && !p.quality ? { ...p, quality } : p.id === photo.id ? { ...p, quality } : p,
        ),
      };
    });
  },

  preloadNeighbors: () => {
    const list = visibleList(get());
    const i = indexOfId(list, get().currentId);
    for (const offset of [-1, 0, 1, 2]) {
      const p = list[i + offset];
      if (p) preloadFull(p);
    }
  },
}));

export function useCurrentPhoto(): Photo | null {
  const currentId = useSorter((s) => s.currentId);
  const photos = useSorter((s) => s.photos);
  return useMemo(() => photos.find((p) => p.id === currentId) ?? null, [photos, currentId]);
}

export function useCounts() {
  const photos = useSorter((s) => s.photos);
  return useMemo(() => countByStatus(photos), [photos]);
}

export function useVisiblePhotos(): Photo[] {
  const photos = useSorter((s) => s.photos);
  const filter = useSorter((s) => s.filter);
  const query = useSorter((s) => s.query);
  const sortOrder = useSorter((s) => s.sortOrder);
  return useMemo(() => applyFilter(photos, filter, query, sortOrder), [photos, filter, query, sortOrder]);
}

export function currentPreviewUrl(photo: Photo | null): string {
  if (!photo) return "";
  return objectUrlFor(photo);
}
