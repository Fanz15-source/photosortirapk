import type { Photo } from "@/lib/types";

export function searchPhotos(photos: Photo[], query: string): Photo[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const out: Photo[] = [];
  for (const p of photos) {
    if (
      p.filename.toLowerCase().includes(q) ||
      p.path.toLowerCase().includes(q) ||
      p.id.toLowerCase().includes(q)
    ) {
      out.push(p);
      if (out.length >= 80) break;
    }
  }
  return out;
}

export function jumpToFile(photos: Photo[], query: string): Photo | null {
  const q = query.trim().toLowerCase();
  if (!q) return null;
  const exact = photos.find((p) => p.filename.toLowerCase() === q);
  if (exact) return exact;
  const withExt = photos.find((p) => p.filename.toLowerCase() === `${q}.jpg`);
  if (withExt) return withExt;
  return photos.find((p) => p.filename.toLowerCase().includes(q)) ?? null;
}
