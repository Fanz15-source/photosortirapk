import { objectUrlFor } from "@/lib/photo-engine";
import type { Photo, QualityAssist } from "@/lib/types";

const cache = new Map<string, QualityAssist>();

function luminanceOf(r: number, g: number, b: number): number {
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function dHash(data: Uint8ClampedArray, w: number, h: number): string {
  let bits = "";
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w - 1; x++) {
      const i = (y * w + x) * 4;
      const j = (y * w + x + 1) * 4;
      const a = luminanceOf(data[i]!, data[i + 1]!, data[i + 2]!);
      const b = luminanceOf(data[j]!, data[j + 1]!, data[j + 2]!);
      bits += a > b ? "1" : "0";
    }
  }
  let hex = "";
  for (let i = 0; i < bits.length; i += 4) {
    hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
  }
  return hex;
}

export function hamming(a: string, b: string): number {
  const n = Math.min(a.length, b.length);
  let d = 0;
  for (let i = 0; i < n; i++) if (a[i] !== b[i]) d += 1;
  d += Math.abs(a.length - b.length);
  return d;
}

function sharpnessBand(score: number): QualityAssist["sharpness"] {
  if (score > 180) return "high";
  if (score > 55) return "medium";
  return "low";
}

function exposureBand(lum: number): QualityAssist["exposure"] {
  if (lum < 28) return "very-dark";
  if (lum < 70) return "dark";
  if (lum > 230) return "very-bright";
  if (lum > 190) return "bright";
  return "good";
}

async function detectFaces(bitmap: ImageBitmap): Promise<number | null> {
  const FD = (window as unknown as { FaceDetector?: new (o: { fastMode: boolean }) => { detect: (img: ImageBitmap) => Promise<unknown[]> } }).FaceDetector;
  if (!FD) return null;
  try {
    const detector = new FD({ fastMode: true });
    const faces = await detector.detect(bitmap);
    return faces.length;
  } catch {
    return null;
  }
}

export async function analyzePhoto(photo: Photo): Promise<QualityAssist | null> {
  const hit = cache.get(photo.sourceKey);
  if (hit) return hit;
  const src = objectUrlFor(photo);
  if (!src || typeof document === "undefined") return null;

  try {
    const res = await fetch(src);
    const blob = await res.blob();
    const bitmap = await createImageBitmap(blob);
    const size = 128;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) {
      bitmap.close();
      return null;
    }
    ctx.drawImage(bitmap, 0, 0, size, size);
    const img = ctx.getImageData(0, 0, size, size);
    const d = img.data;

    let sum = 0;
    let hi = 0;
    let lo = 0;
    let lap = 0;
    for (let y = 1; y < size - 1; y++) {
      for (let x = 1; x < size - 1; x++) {
        const i = (y * size + x) * 4;
        const lum = luminanceOf(d[i]!, d[i + 1]!, d[i + 2]!);
        sum += lum;
        if (lum > 245) hi += 1;
        if (lum < 12) lo += 1;
        const up = luminanceOf(d[i - size * 4]!, d[i - size * 4 + 1]!, d[i - size * 4 + 2]!);
        const down = luminanceOf(d[i + size * 4]!, d[i + size * 4 + 1]!, d[i + size * 4 + 2]!);
        const left = luminanceOf(d[i - 4]!, d[i - 3]!, d[i - 2]!);
        const right = luminanceOf(d[i + 4]!, d[i + 5]!, d[i + 6]!);
        const v = Math.abs(4 * lum - up - down - left - right);
        lap += v;
      }
    }
    const pixels = size * size;
    const inner = (size - 2) * (size - 2);
    const luminance = sum / pixels;
    const sharpnessScore = lap / inner;
    const hashCanvas = document.createElement("canvas");
    hashCanvas.width = 9;
    hashCanvas.height = 8;
    const hctx = hashCanvas.getContext("2d");
    let phash = "";
    if (hctx) {
      hctx.drawImage(bitmap, 0, 0, 9, 8);
      phash = dHash(hctx.getImageData(0, 0, 9, 8).data, 9, 8);
    }
    const faces = await detectFaces(bitmap);
    bitmap.close();

    const result: QualityAssist = {
      sharpness: sharpnessBand(sharpnessScore),
      sharpnessScore,
      exposure: exposureBand(luminance),
      luminance,
      highlightClip: hi / pixels,
      shadowClip: lo / pixels,
      faces,
      eyes: faces === null ? "n/a" : "n/a",
      duplicateSimilarity: 0,
      phash,
    };
    cache.set(photo.sourceKey, result);
    return result;
  } catch {
    return null;
  }
}

export function similarityPercent(a: QualityAssist | null, b: QualityAssist | null): number {
  if (!a?.phash || !b?.phash) return 0;
  const dist = hamming(a.phash, b.phash);
  const max = Math.max(a.phash.length, 1);
  return Math.round((1 - dist / max) * 100);
}

export function similarGroup(photos: Photo[], current: Photo, limit = 8): Photo[] {
  if (!current.quality?.phash) {
    return photos.filter((p) => p.sourceKey === current.sourceKey && p.id !== current.id).slice(0, limit);
  }
  const scored = photos
    .filter((p) => p.id !== current.id && p.quality?.phash)
    .map((p) => ({ p, sim: similarityPercent(current.quality, p.quality) }))
    .filter((x) => x.sim >= 86)
    .sort((a, b) => b.sim - a.sim);
  return scored.slice(0, limit).map((x) => x.p);
}

export function getCachedQuality(sourceKey: string): QualityAssist | null {
  return cache.get(sourceKey) ?? null;
}
