export type PhotoStatus = "unsorted" | "select" | "alternative" | "reject";
export type FileMode = "copy" | "move";
export type ViewMode = "home" | "setup" | "workspace" | "complete";
export type FilterId = "all" | PhotoStatus;
export type SortId =
  | "filename-az"
  | "filename-za"
  | "date-taken"
  | "date-modified"
  | "file-size"
  | "camera"
  | "focal-length";

export type ConflictChoice = "skip" | "replace" | "rename";

export interface QualityAssist {
  sharpness: "low" | "medium" | "high";
  sharpnessScore: number;
  exposure: "very-dark" | "dark" | "good" | "bright" | "very-bright";
  luminance: number;
  highlightClip: number;
  shadowClip: number;
  faces: number | null;
  eyes: "open" | "closed" | "n/a";
  duplicateSimilarity: number;
  phash: string;
}

export interface Photo {
  id: string;
  filename: string;
  path: string;
  status: PhotoStatus;
  timestamp: number | null;
  size: number;
  width: number;
  height: number;
  format: string;
  createdAt: string | null;
  modifiedAt: string | null;
  dateTaken: string | null;
  camera: string | null;
  lens: string | null;
  iso: number | null;
  shutter: string | null;
  aperture: string | null;
  focalLength: string | null;
  sourceKey: string;
  destFilename: string | null;
  destPath: string | null;
  error: string | null;
  rotation: number;
  isDemo: boolean;
  isRaw: boolean;
  quality: QualityAssist | null;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  sourceFolder: string;
  selectFolder: string;
  alternativeFolder: string;
  rejectFolder: string;
  mode: FileMode;
  isDemo: boolean;
  photoCount: number;
}

export interface PhotoStatusRecord {
  status: PhotoStatus;
  timestamp: number | null;
  destPath: string | null;
  destFilename: string | null;
  rotation: number;
  error: string | null;
}

export interface CategorizeOp {
  type: "categorize";
  photoId: string;
  from: PhotoStatus;
  to: PhotoStatus;
  fromDest: string | null;
  toDest: string | null;
  fromDestName: string | null;
  toDestName: string | null;
}

export type HistoryOp = CategorizeOp;

export interface SessionRecord {
  project: Project;
  currentId: string | null;
  filter: FilterId;
  sortOrder: SortId;
  fastSort: boolean;
  thumbnailSize: number;
  qualityAssist: boolean;
  showSimilar: boolean;
  autoAdvance: boolean;
  statuses: Record<string, PhotoStatusRecord>;
  undo: HistoryOp[];
  redo: HistoryOp[];
}

export interface ConflictState {
  photoId: string;
  filename: string;
  folder: string;
  status: Exclude<PhotoStatus, "unsorted">;
}

export interface FileErrorState {
  photoId: string;
  filename: string;
  reason: string;
}

export const SUPPORTED_IMAGE_EXT = [
  "jpg",
  "jpeg",
  "png",
  "webp",
  "tif",
  "tiff",
  "gif",
  "bmp",
  "avif",
  "heic",
  "heif",
] as const;

export const RAW_EXT = ["arw", "cr2", "cr3", "nef", "raf", "dng", "orf", "rw2"] as const;

export const ALL_EXT = [...SUPPORTED_IMAGE_EXT, ...RAW_EXT];

export function extOf(filename: string): string {
  const d = filename.lastIndexOf(".");
  return d >= 0 ? filename.slice(d + 1).toLowerCase() : "";
}

export function isSupportedFilename(filename: string): boolean {
  return (ALL_EXT as readonly string[]).includes(extOf(filename));
}

export function isRawFilename(filename: string): boolean {
  return (RAW_EXT as readonly string[]).includes(extOf(filename));
}

export function formatOf(filename: string): string {
  const e = extOf(filename);
  if (e === "jpg" || e === "jpeg") return "JPEG";
  if (e === "tif" || e === "tiff") return "TIFF";
  return e.toUpperCase() || "FILE";
}

export const FOLDER_OF: Record<Exclude<PhotoStatus, "unsorted">, "selectFolder" | "alternativeFolder" | "rejectFolder"> =
  {
    select: "selectFolder",
    alternative: "alternativeFolder",
    reject: "rejectFolder",
  };
