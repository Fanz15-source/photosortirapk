export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatRes(w: number, h: number): string {
  if (!w || !h) return "—";
  return `${w.toLocaleString()} × ${h.toLocaleString()}`;
}

export function formatWhen(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function formatProgress(done: number, total: number): string {
  if (!total) return "0%";
  const pct = (done / total) * 100;
  return `${pct.toFixed(2)}%`;
}

export function padIndex(n: number, width = 4): string {
  return String(n).padStart(width, "0");
}
