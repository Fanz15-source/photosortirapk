import type { Photo } from "@/lib/types";
import { formatOf, isRawFilename, isSupportedFilename } from "@/lib/types";
import { demoUrl } from "@/lib/demo/catalog";

const blobUrls = new Map<string, string>();
const fileBlobs = new Map<string, Blob>();

export function rememberBlob(id: string, blob: Blob) {
  fileBlobs.set(id, blob);
}

export function getBlob(id: string): Blob | null {
  return fileBlobs.get(id) ?? null;
}

export function objectUrlFor(photo: Photo): string {
  if (photo.isDemo) return demoUrl(photo);
  const existing = blobUrls.get(photo.id);
  if (existing) return existing;
  const blob = fileBlobs.get(photo.id);
  if (!blob) return "";
  const url = URL.createObjectURL(blob);
  blobUrls.set(photo.id, url);
  return url;
}

export function revokeAllUrls() {
  for (const url of blobUrls.values()) URL.revokeObjectURL(url);
  blobUrls.clear();
}

export function collectImageFiles(fileList: File[]): File[] {
  return fileList.filter((f) => isSupportedFilename(f.name)).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
}

export async function indexFiles(files: File[], sourceFolder: string): Promise<Photo[]> {
  const photos: Photo[] = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i]!;
    rememberBlob(`file-${i}-${file.name}`, file);
    const id = `file-${i}-${file.name}`;
    photos.push({
      id,
      filename: file.name,
      path: `${sourceFolder}/${file.name}`,
      status: "unsorted",
      timestamp: null,
      size: file.size,
      width: 0,
      height: 0,
      format: formatOf(file.name),
      createdAt: file.lastModified ? new Date(file.lastModified).toISOString() : null,
      modifiedAt: file.lastModified ? new Date(file.lastModified).toISOString() : null,
      dateTaken: null,
      camera: null,
      lens: null,
      iso: null,
      shutter: null,
      aperture: null,
      focalLength: null,
      sourceKey: id,
      destFilename: null,
      destPath: null,
      error: null,
      rotation: 0,
      isDemo: false,
      isRaw: isRawFilename(file.name),
      quality: null,
    });
  }
  return photos;
}

export async function readExif(photo: Photo): Promise<Partial<Photo>> {
  if (photo.isDemo) return {};
  const blob = getBlob(photo.id);
  if (!blob) return {};
  try {
    const exifr = (await import("exifr")).default;
    const data = await exifr.parse(blob, {
      pick: [
        "Make",
        "Model",
        "LensModel",
        "Lens",
        "ISO",
        "ISOSpeedRatings",
        "ExposureTime",
        "FNumber",
        "FocalLength",
        "DateTimeOriginal",
        "CreateDate",
        "ImageWidth",
        "ImageHeight",
        "ExifImageWidth",
        "ExifImageHeight",
      ],
    });
    if (!data) return {};
    const camera = [data.Make, data.Model].filter(Boolean).join(" ") || null;
    const shutter =
      typeof data.ExposureTime === "number"
        ? data.ExposureTime >= 1
          ? `${data.ExposureTime}s`
          : `1/${Math.round(1 / data.ExposureTime)}`
        : null;
    return {
      camera,
      lens: data.LensModel ?? data.Lens ?? null,
      iso: data.ISO ?? data.ISOSpeedRatings ?? null,
      shutter,
      aperture: typeof data.FNumber === "number" ? `f/${data.FNumber}` : null,
      focalLength: typeof data.FocalLength === "number" ? `${Math.round(data.FocalLength)}mm` : null,
      dateTaken: data.DateTimeOriginal
        ? new Date(data.DateTimeOriginal).toISOString()
        : data.CreateDate
          ? new Date(data.CreateDate).toISOString()
          : null,
      width: data.ImageWidth ?? data.ExifImageWidth ?? photo.width,
      height: data.ImageHeight ?? data.ExifImageHeight ?? photo.height,
    };
  } catch {
    return {};
  }
}

export async function rawPreviewUrl(photo: Photo): Promise<string | null> {
  if (!photo.isRaw) return objectUrlFor(photo) || null;
  const blob = getBlob(photo.id);
  if (!blob) return null;
  try {
    const exifr = (await import("exifr")).default;
    const url = await exifr.thumbnailUrl(blob);
    return typeof url === "string" ? url : null;
  } catch {
    return null;
  }
}

export function looksLikeImage(name: string): boolean {
  return isSupportedFilename(name);
}
