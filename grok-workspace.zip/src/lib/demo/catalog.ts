import type { Photo, QualityAssist } from "@/lib/types";
import { padIndex } from "@/lib/format";

export const DEMO_PROJECT_ID = "demo-fls3n-2026";
export const DEMO_COUNT = 5000;
export const DEMO_NAME = "FLS3N_2026";
export const DEMO_SOURCE = "Demo / FLS3N 2026";

export interface DemoSource {
  key: string;
  url: string;
  label: string;
  width: number;
  height: number;
  camera: string;
  lens: string;
  iso: number;
  shutter: string;
  aperture: string;
  focalLength: string;
  size: number;
}

export const DEMO_SOURCES: DemoSource[] = [
  {
    key: "dancer",
    url: "/demo/dancer.jpg",
    label: "traditional dancer",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 800,
    shutter: "1/250",
    aperture: "f/4.0",
    focalLength: "70mm",
    size: 8_388_608,
  },
  {
    key: "choir",
    url: "/demo/choir.jpg",
    label: "choir",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 1600,
    shutter: "1/125",
    aperture: "f/4.0",
    focalLength: "35mm",
    size: 9_437_184,
  },
  {
    key: "portrait",
    url: "/demo/portrait.jpg",
    label: "portrait",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 400,
    shutter: "1/320",
    aperture: "f/4.0",
    focalLength: "105mm",
    size: 7_340_032,
  },
  {
    key: "gamelan",
    url: "/demo/gamelan.jpg",
    label: "gamelan",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 640,
    shutter: "1/160",
    aperture: "f/4.0",
    focalLength: "55mm",
    size: 8_912_896,
  },
  {
    key: "dance",
    url: "/demo/dance.jpg",
    label: "contemporary dance",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 3200,
    shutter: "1/500",
    aperture: "f/4.0",
    focalLength: "50mm",
    size: 6_815_744,
  },
  {
    key: "audience",
    url: "/demo/audience.jpg",
    label: "audience",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 6400,
    shutter: "1/80",
    aperture: "f/4.0",
    focalLength: "18mm",
    size: 5_505_024,
  },
  {
    key: "backstage",
    url: "/demo/backstage.jpg",
    label: "backstage",
    width: 6000,
    height: 4000,
    camera: "Sony ILCE-6400",
    lens: "E 18-105mm F4 G OSS",
    iso: 1250,
    shutter: "1/60",
    aperture: "f/4.0",
    focalLength: "24mm",
    size: 10_485_760,
  },
];

const BURST = 4;

export function sourceForIndex(index: number): DemoSource {
  const burstGroup = Math.floor(index / BURST);
  return DEMO_SOURCES[burstGroup % DEMO_SOURCES.length]!;
}

export function makeDemoPhoto(index: number): Photo {
  const src = sourceForIndex(index);
  const n = index + 1;
  const filename = `IMG_${padIndex(n)}.JPG`;
  const burstOffset = index % BURST;
  const isoJitter = src.iso + burstOffset * 50;
  const taken = new Date(Date.UTC(2026, 8, 23, 14, 35, 0) + index * 1200);
  const isoStamp = taken.toISOString();

  return {
    id: `demo-${padIndex(n)}`,
    filename,
    path: `${DEMO_SOURCE}/${filename}`,
    status: "unsorted",
    timestamp: null,
    size: src.size + burstOffset * 17_408,
    width: src.width,
    height: src.height,
    format: "JPEG",
    createdAt: isoStamp,
    modifiedAt: isoStamp,
    dateTaken: isoStamp.replace("T", " ").slice(0, 19),
    camera: src.camera,
    lens: src.lens,
    iso: isoJitter,
    shutter: src.shutter,
    aperture: src.aperture,
    focalLength: src.focalLength,
    sourceKey: src.key,
    destFilename: null,
    destPath: null,
    error: null,
    rotation: 0,
    isDemo: true,
    isRaw: false,
    quality: null,
  };
}

export function buildDemoCatalog(): Photo[] {
  const photos = new Array<Photo>(DEMO_COUNT);
  for (let i = 0; i < DEMO_COUNT; i++) photos[i] = makeDemoPhoto(i);
  return photos;
}

export function demoUrl(photo: Photo): string {
  const src = DEMO_SOURCES.find((s) => s.key === photo.sourceKey);
  return src?.url ?? DEMO_SOURCES[0]!.url;
}

const qualityCache = new Map<string, QualityAssist>();

export function cacheDemoQuality(sourceKey: string, q: QualityAssist) {
  qualityCache.set(sourceKey, q);
}

export function demoQuality(sourceKey: string): QualityAssist | null {
  return qualityCache.get(sourceKey) ?? null;
}
