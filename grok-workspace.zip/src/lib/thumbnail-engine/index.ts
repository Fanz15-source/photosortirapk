import { objectUrlFor } from "@/lib/photo-engine";
import type { Photo } from "@/lib/types";

const memory = new Map<string, string>();
const inflight = new Map<string, Promise<string>>();

export function thumbKey(photo: Photo, size: number): string {
  return `${photo.sourceKey}:${size}`;
}

function drawThumb(bitmap: ImageBitmap, size: number): string {
  const scale = Math.min(size / bitmap.width, size / bitmap.height, 1);
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) return "";
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "medium";
  ctx.drawImage(bitmap, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", 0.72);
}

export async function getThumbnail(photo: Photo, size: number): Promise<string> {
  const key = thumbKey(photo, size);
  const hit = memory.get(key);
  if (hit) return hit;
  const pending = inflight.get(key);
  if (pending) return pending;

  const work = (async () => {
    const src = objectUrlFor(photo);
    if (!src) return "";
    try {
      const res = await fetch(src);
      const blob = await res.blob();
      const bitmap = await createImageBitmap(blob);
      const url = drawThumb(bitmap, size);
      bitmap.close();
      if (url) memory.set(key, url);
      return url;
    } catch {
      return src;
    }
  })();

  inflight.set(key, work);
  try {
    return await work;
  } finally {
    inflight.delete(key);
  }
}

export function preloadFull(photo: Photo): void {
  const src = objectUrlFor(photo);
  if (!src) return;
  const img = new Image();
  img.decoding = "async";
  img.src = src;
}
