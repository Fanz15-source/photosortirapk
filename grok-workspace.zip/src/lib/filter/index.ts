import type { FilterId, Photo, SortId } from "@/lib/types";

export function statusLabel(filter: FilterId): string {
  switch (filter) {
    case "all":
      return "All";
    case "select":
      return "Select";
    case "alternative":
      return "Alternative";
    case "reject":
      return "Reject";
    case "unsorted":
      return "Unsorted";
  }
}

export function countByStatus(photos: Photo[]) {
  const counts = {
    all: photos.length,
    select: 0,
    alternative: 0,
    reject: 0,
    unsorted: 0,
  };
  for (const p of photos) counts[p.status] += 1;
  return counts;
}

function cmpStr(a: string | null, b: string | null): number {
  return (a ?? "").localeCompare(b ?? "", undefined, { numeric: true, sensitivity: "base" });
}

export function sortPhotos(photos: Photo[], sort: SortId): Photo[] {
  const list = photos.slice();
  switch (sort) {
    case "filename-az":
      list.sort((a, b) => cmpStr(a.filename, b.filename));
      break;
    case "filename-za":
      list.sort((a, b) => cmpStr(b.filename, a.filename));
      break;
    case "date-taken":
      list.sort((a, b) => cmpStr(a.dateTaken, b.dateTaken) || cmpStr(a.filename, b.filename));
      break;
    case "date-modified":
      list.sort((a, b) => cmpStr(a.modifiedAt, b.modifiedAt) || cmpStr(a.filename, b.filename));
      break;
    case "file-size":
      list.sort((a, b) => b.size - a.size || cmpStr(a.filename, b.filename));
      break;
    case "camera":
      list.sort((a, b) => cmpStr(a.camera, b.camera) || cmpStr(a.filename, b.filename));
      break;
    case "focal-length":
      list.sort((a, b) => cmpStr(a.focalLength, b.focalLength) || cmpStr(a.filename, b.filename));
      break;
  }
  return list;
}

export function applyFilter(photos: Photo[], filter: FilterId, query: string, sort: SortId): Photo[] {
  const q = query.trim().toLowerCase();
  let list = photos;
  if (filter !== "all") list = list.filter((p) => p.status === filter);
  if (q) {
    list = list.filter(
      (p) =>
        p.filename.toLowerCase().includes(q) ||
        p.path.toLowerCase().includes(q) ||
        p.format.toLowerCase().includes(q) ||
        (p.camera ?? "").toLowerCase().includes(q),
    );
  }
  return sortPhotos(list, sort);
}

export function nextUnsortedIndex(photos: Photo[], fromIndex: number, dir: 1 | -1): number {
  if (!photos.length) return 0;
  const len = photos.length;
  for (let step = 1; step <= len; step++) {
    const i = (fromIndex + dir * step + len * 8) % len;
    if (photos[i]?.status === "unsorted") return i;
  }
  return Math.max(0, Math.min(fromIndex, len - 1));
}
