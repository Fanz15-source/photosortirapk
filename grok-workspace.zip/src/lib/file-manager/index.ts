import type { FileMode, Photo, PhotoStatus, Project } from "@/lib/types";
import { FOLDER_OF } from "@/lib/types";
import { uniqueName } from "@/lib/utils";

export type DestHandles = {
  select?: FileSystemDirectoryHandle;
  alternative?: FileSystemDirectoryHandle;
  reject?: FileSystemDirectoryHandle;
};

export interface PlaceResult {
  ok: boolean;
  skipped?: boolean;
  destFilename: string | null;
  destPath: string | null;
  error?: string;
  conflict?: boolean;
}

function folderPath(project: Project, status: Exclude<PhotoStatus, "unsorted">): string {
  return project[FOLDER_OF[status]];
}

async function writeToDir(
  dir: FileSystemDirectoryHandle,
  filename: string,
  blob: Blob,
): Promise<void> {
  const handle = await dir.getFileHandle(filename, { create: true });
  const writable = await handle.createWritable();
  await writable.write(blob);
  await writable.close();
}

export async function listDirNames(dir: FileSystemDirectoryHandle | undefined): Promise<Set<string>> {
  const names = new Set<string>();
  if (!dir) return names;
  try {
    for await (const entry of dir.values()) names.add(entry.name);
  } catch {
    /* ignore */
  }
  return names;
}

export async function placePhoto(opts: {
  photo: Photo;
  status: Exclude<PhotoStatus, "unsorted">;
  project: Project;
  blob: Blob | null;
  destHandles: DestHandles;
  existingNames: Set<string>;
  mode: FileMode;
  conflictChoice?: "skip" | "replace" | "rename";
}): Promise<PlaceResult> {
  const { photo, status, project, blob, destHandles, existingNames, conflictChoice } = opts;
  const folder = folderPath(project, status);
  let destFilename = photo.filename;

  if (existingNames.has(destFilename)) {
    if (!conflictChoice) return { ok: false, conflict: true, destFilename, destPath: `${folder}/${destFilename}` };
    if (conflictChoice === "skip") {
      return { ok: true, skipped: true, destFilename: null, destPath: null };
    }
    if (conflictChoice === "rename") destFilename = uniqueName(photo.filename, existingNames);
  }

  const destPath = `${folder}/${destFilename}`;

  if (project.isDemo || !blob) {
    existingNames.add(destFilename);
    return { ok: true, destFilename, destPath };
  }

  const dir = destHandles[status];
  if (!dir) {
    existingNames.add(destFilename);
    return { ok: true, destFilename, destPath };
  }

  try {
    await writeToDir(dir, destFilename, blob);
    existingNames.add(destFilename);
    return { ok: true, destFilename, destPath };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    const reason = /denied|permission/i.test(message)
      ? "Permission denied"
      : /quota|space|full/i.test(message)
        ? "Disk full"
        : /lock|busy/i.test(message)
          ? "File locked"
          : /missing|not found/i.test(message)
            ? "File missing"
            : message;
    return { ok: false, destFilename: null, destPath: null, error: reason };
  }
}

export function virtualDest(project: Project, status: PhotoStatus, filename: string | null): string | null {
  if (status === "unsorted" || !filename) return null;
  return `${project[FOLDER_OF[status]]}/${filename}`;
}
