import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import type { SessionRecord } from "@/lib/types";

interface SorterDB extends DBSchema {
  session: {
    key: "current";
    value: SessionRecord;
  };
  blobs: {
    key: string;
    value: { key: string; blob: Blob };
  };
}

let dbPromise: Promise<IDBPDatabase<SorterDB>> | null = null;

function getDb() {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("IndexedDB unavailable"));
  }
  if (!dbPromise) {
    dbPromise = openDB<SorterDB>("photo-sorter", 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("session")) db.createObjectStore("session");
        if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
      },
    });
  }
  return dbPromise;
}

export async function loadSession(): Promise<SessionRecord | null> {
  try {
    const db = await getDb();
    return (await db.get("session", "current")) ?? null;
  } catch {
    return null;
  }
}

export async function saveSession(record: SessionRecord): Promise<void> {
  try {
    const db = await getDb();
    await db.put("session", record, "current");
  } catch {
    // Persistence is best-effort; sorting still works in memory.
  }
}

export async function clearSession(): Promise<void> {
  try {
    const db = await getDb();
    await db.delete("session", "current");
  } catch {
    /* ignore */
  }
}

export async function putBlob(key: string, blob: Blob): Promise<void> {
  try {
    const db = await getDb();
    await db.put("blobs", { key, blob }, key);
  } catch {
    /* ignore */
  }
}

export async function getBlob(key: string): Promise<Blob | null> {
  try {
    const db = await getDb();
    const row = await db.get("blobs", key);
    return row?.blob ?? null;
  } catch {
    return null;
  }
}
