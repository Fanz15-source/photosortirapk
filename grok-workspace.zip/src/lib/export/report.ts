import type { Photo, Project } from "@/lib/types";

function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export function buildCsv(photos: Photo[]): string {
  const header = "filename,status,path,timestamp";
  const rows = photos
    .filter((p) => p.status !== "unsorted")
    .map((p) => {
      const ts = p.timestamp ? new Date(p.timestamp).toISOString().replace("T", " ").slice(0, 19) : "";
      const path = p.destPath ?? p.path;
      return [p.filename, p.status.toUpperCase(), path, ts].map(csvEscape).join(",");
    });
  return [header, ...rows].join("\n");
}

export function buildJson(project: Project, photos: Photo[]): string {
  return JSON.stringify(
    {
      project: project.name,
      source: project.sourceFolder,
      mode: project.mode,
      exportedAt: new Date().toISOString(),
      photos: photos
        .filter((p) => p.status !== "unsorted")
        .map((p) => ({
          filename: p.filename,
          status: p.status.toUpperCase(),
          path: p.destPath ?? p.path,
          timestamp: p.timestamp ? new Date(p.timestamp).toISOString() : null,
        })),
    },
    null,
    2,
  );
}

export function downloadText(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
